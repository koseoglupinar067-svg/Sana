package com.noxnoclient.module.combat

import com.noxnoclient.utils.CombatUtil
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.*
import com.noxnoclient.module.social.isFriendEntity
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.RotationEngine
import kotlinx.coroutines.*
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.atan2

class KillAura : BaseModule(
    name        = "KillAura",
    category    = ModuleCategory.COMBAT,
    description = "Automatic attack - Max Damage"
), PacketEventBus.PacketListener {

    enum class AttackMode   { Single, Multi, Closest }
    enum class PriorityMode { Distance, Health, LowestHealth, Direction }
    enum class CritMode     { UltraFast, MovePacket, InputFlag, None }

    private val cpsMin          = int  ("CPS Min",          20,    0,  20)
    private val cpsMax          = int  ("CPS Max",          20,    0,  20)
    private val range           = float("Range",            5f,   1f,  18f)
    private val fov             = int  ("FOV",              360,   30, 360)
    private val maxTargets      = int  ("Max Targets",       1,    1,  10)
    private val attackMode      = enum ("Attack Mode",      AttackMode.Single)
    private val priorityMode    = enum ("Priority",         PriorityMode.LowestHealth)
    private val reversePriority = bool ("Reverse Priority", false)
    private val critMode        = enum ("Crit Mode",        CritMode.UltraFast)
    private val critInjectionCooldownMs = int("Crit Cooldown", 0, 0, 1000)
    private val headLock        = bool ("Head Lock",        true)
    private val rotationMode    = enum ("Rotation Mode",    RotationEngine.Mode.GCD)
    private val headLockSmooth  = float("Head Lock Smooth", 0.9f, 0.01f, 1f)
    private val ignoreFriends   = bool ("Ignore Friends",   true)
    private val antiBot         = bool ("Anti Bot",         true)
    private val requireLos      = bool ("Require LOS",      false)
    private val shortcut        = bool ("Shortcut",         false)

    private val keepDistance          = bool ("Keep Distance",           false)
    private val teleportBehind        = bool ("Teleport Behind",         false)
    private val strafe                = bool ("Strafe",                 false)
    private val strafeSpeed           = float("Strafe Speed",           30f,  1f,  30f)
    private val keepDistanceRange     = float("Keep Distance",           4f,   1f,  10f)
    private val keepDistanceTolerance = float("Keep Distance Tolerance", 0.4f, 0.1f, 3f)
    private val keepDistanceSpeed     = float("Keep Distance Speed",     8f,   1f,  8f)
    private val keepDistanceYOffset   = float("Keep Distance Y Offset",  0f,  -10f, 10f)
    private val keepDistanceRetreatOnly = bool("Retreat Only",           false)
    private val knockbackReact        = bool ("Knockback React",        false)
    private val knockbackPredictSec   = float("Predict Ahead",          0.15f, 0.05f, 0.5f)
    private val knockbackMinSpeed     = float("Min Speed",              0.15f, 0.02f, 1f)

    companion object {
        private const val CRIT_LOCK_KEY = "crit-injection-killaura"
        private const val INPUT_TICK_MS = 50L
    }

    @Volatile private var pendingAttack  = false
    @Volatile private var lastAttackMs   = 0L
    @Volatile private var lastScanMs     = 0L
    @Volatile private var cachedTargets: List<EntityTracker.TrackedEntity> = emptyList()
    @Volatile private var currentTargetId: Long = 0L
    @Volatile private var headLockYaw    = 0f
    @Volatile private var headLockPitch  = 0f
    @Volatile private var critPending    = false
    @Volatile private var lastMovePacketCritMs = 0L
    @Volatile private var strafeAngle    = 0f

    private var tickJob: Job? = null

    override fun onEnable() {
        super.onEnable()
        pendingAttack = false
        lastAttackMs  = 0L
        lastScanMs    = 0L
        cachedTargets = emptyList()
        currentTargetId = 0L
        headLockYaw   = EntityTracker.selfYaw
        headLockPitch = EntityTracker.selfPitch
        critPending   = false
        lastMovePacketCritMs = 0L
        strafeAngle   = 0f
        PacketEventBus.register(this)
        tickJob = scope.launch { tickLoop() }
    }

    override fun onDisable() {
        tickJob?.cancel()
        PacketEventBus.unregister(this)
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        val pkt = event.packet as? PlayerAuthInputPacket ?: return

        val targets = cachedTargets
        val primary = targets.firstOrNull()

        if ((headLock.value || keepDistance.value) && primary != null) {
            val fromX = EntityTracker.selfX
            val fromY = EntityTracker.selfY
            val fromZ = EntityTracker.selfZ

            var newYaw = EntityTracker.selfYaw
            var newPitch = EntityTracker.selfPitch
            if (headLock.value) {
                val target = RotationEngine.rotationTo(fromX, fromY, fromZ, primary, rotationMode.value)
                val f = headLockSmooth.value.coerceAtLeast(0.85f)
                val stepped = RotationEngine.step(headLockYaw, headLockPitch, target, rotationMode.value, f)
                headLockYaw = stepped.yaw
                headLockPitch = stepped.pitch
                newYaw = headLockYaw
                newPitch = headLockPitch
            }

            var newPos = Vector3f.from(fromX, fromY, fromZ)
            if (keepDistance.value) {
                newPos = applyKeepDistance(Vector3f.from(fromX, fromY, fromZ), primary)
            }

            EntityTracker.selfYaw = newYaw
            EntityTracker.selfPitch = newPitch
            EntityTracker.selfX = newPos.x
            EntityTracker.selfY = newPos.y
            EntityTracker.selfZ = newPos.z

            val session = event.session
            val onGround = EntityTracker.selfOnGround
            scope.launch {
                try {
                    CombatUtil.TimerPvP.dispatch(
                        session, fromX, fromY, fromZ,
                        newPos.x, newPos.y, newPos.z,
                        newYaw, newPitch, onGround
                    )
                } catch (_: Exception) {}
            }
        }

        val session = event.session
        val slot = EntityTracker.selfHotbarSlot.coerceIn(0, 8)

        if (pendingAttack && primary != null) {
            pendingAttack = false

            val wantsCrit = critPending
            critPending = false

            if (wantsCrit && CombatUtil.tryAcquire(CRIT_LOCK_KEY)) {
                try {
                    if (EntityTracker.selfSprinting) {
                        pkt.inputData.add(PlayerAuthInputData.STOP_SPRINTING)
                    }

                    if (EntityTracker.selfOnGround) {
                        when (critMode.value) {
                            CritMode.UltraFast, CritMode.InputFlag -> {
                                pkt.inputData.add(PlayerAuthInputData.JUMPING)
                            }
                            CritMode.MovePacket -> {
                                CombatUtil.sendMoveAtSelf(session, dyOffset = 0.42f, onGround = false)
                            }
                            CritMode.None -> {}
                        }
                    }

                    val targetsToHit = if (attackMode.value == AttackMode.Multi) {
                        targets.take(maxTargets.value)
                    } else listOf(primary)

                    CombatUtil.sendSwing(session)
                    targetsToHit.forEach { t ->
                        if (requireLos.value && !hasLos(t)) return@forEach
                        val clickPos = Vector3f.from(t.x, t.y + 1.62f, t.z)
                        CombatUtil.sendAttack(session, t.runtimeId, slot, clickPos)
                    }

                    if (EntityTracker.selfOnGround && critMode.value == CritMode.MovePacket) {
                        CombatUtil.sendMoveAtSelf(session, dyOffset = 0f, onGround = true)
                    }
                } finally {
                    CombatUtil.release(CRIT_LOCK_KEY)
                }
            } else {
                val targetsToHit = if (attackMode.value == AttackMode.Multi) {
                    targets.take(maxTargets.value)
                } else listOf(primary)

                CombatUtil.sendSwing(session)
                targetsToHit.forEach { t ->
                    if (requireLos.value && !hasLos(t)) return@forEach
                    val clickPos = Vector3f.from(t.x, t.y + 1.62f, t.z)
                    CombatUtil.sendAttack(session, t.runtimeId, slot, clickPos)
                }
            }
        }

        event.cancelAndReplace(pkt)
    }

    private suspend fun tickLoop() {
        while (currentCoroutineContext().isActive) {
            if (isEnabled) tick()
            delay(20L)
        }
    }

    private fun tick() {
        val now = System.currentTimeMillis()
        val delayMs = MathUtil.cpsToDelayMs(cpsMin.value, cpsMax.value)

        if (now - lastAttackMs < delayMs) return

        if (now - lastScanMs >= 50L) {
            cachedTargets = selectTargets()
            currentTargetId = cachedTargets.firstOrNull()?.runtimeId ?: 0L
            lastScanMs = now
        }

        if (cachedTargets.isEmpty()) return

        lastAttackMs = now

        val critBlocked = EntityTracker.selfInWater || EntityTracker.selfBlinded
        critPending = critMode.value != CritMode.None && !critBlocked
        pendingAttack = true
    }

    fun currentTarget(): EntityTracker.TrackedEntity? = cachedTargets.firstOrNull { it.runtimeId == currentTargetId }

    private fun selectTargets(): List<EntityTracker.TrackedEntity> {
        val sx = EntityTracker.selfX; val sy = EntityTracker.selfY; val sz = EntityTracker.selfZ
        val raw = EntityTracker.getEntitiesInRange(range.value)
        val needsAngle = fov.value < 360 || priorityMode.value == PriorityMode.Direction

        data class Scored(val entity: EntityTracker.TrackedEntity, val key: Float)
        val scored = ArrayList<Scored>(raw.size)
        for (e in raw) {
            if (!e.isPlayer || e.runtimeId == EntityTracker.selfRuntimeId) continue
            val angle = if (needsAngle) EntityTracker.angleToEntity(e) else 0f
            if (fov.value < 360 && angle > fov.value / 2f) continue
            if (ignoreFriends.value && e.isFriendEntity) continue
            if (antiBot.value && e.isLikelyBot()) continue
            val key = when (priorityMode.value) {
                PriorityMode.Distance -> MathUtil.dist3sq(e.x, e.y, e.z, sx, sy, sz)
                PriorityMode.Health,
                PriorityMode.LowestHealth -> e.health
                PriorityMode.Direction -> angle
            }
            scored.add(Scored(e, key))
        }
        scored.sortBy { if (reversePriority.value) -it.key else it.key }
        return scored.map { it.entity }
    }

    private fun hasLos(t: EntityTracker.TrackedEntity): Boolean = MathUtil.hasLineOfSight(
        EntityTracker.selfX, EntityTracker.selfY + 1.62f, EntityTracker.selfZ,
        t.x, t.y + 1.2f, t.z
    )

    private fun applyKeepDistance(pos: Vector3f, target: EntityTracker.TrackedEntity): Vector3f {
        val maxStep = keepDistanceSpeed.value * (INPUT_TICK_MS / 1000f)

        val desiredY = target.y + keepDistanceYOffset.value
        val diffY = desiredY - pos.y
        val newY = if (kotlin.math.abs(diffY) <= keepDistanceTolerance.value) pos.y
                   else pos.y + diffY.coerceIn(-maxStep, maxStep)

        val kbSpeed = MathUtil.dist2(0f, 0f, target.velX, target.velZ)
        val reacting = knockbackReact.value && kbSpeed >= knockbackMinSpeed.value
        val effTargetX = if (reacting) target.x + target.velX * knockbackPredictSec.value else target.x
        val effTargetZ = if (reacting) target.z + target.velZ * knockbackPredictSec.value else target.z

        if (teleportBehind.value) {
            val yawRad = Math.toRadians(target.yaw.toDouble()).toFloat()
            val behindX = effTargetX + kotlin.math.sin(yawRad) * keepDistanceRange.value
            val behindZ = effTargetZ - kotlin.math.cos(yawRad) * keepDistanceRange.value
            return stepToward(pos, newY, behindX, behindZ, maxStep)
        }

        if (strafe.value) {
            strafeAngle = if (reacting) {
                val kbAngleDeg = Math.toDegrees(atan2(target.velX.toDouble(), target.velZ.toDouble())).toFloat()
                (kbAngleDeg + 180f).mod(360f)
            } else {
                (strafeAngle + strafeSpeed.value) % 360f
            }
            val rad = Math.toRadians(strafeAngle.toDouble())
            val orbitX = effTargetX + (kotlin.math.sin(rad) * keepDistanceRange.value).toFloat()
            val orbitZ = effTargetZ + (kotlin.math.cos(rad) * keepDistanceRange.value).toFloat()
            return stepToward(pos, newY, orbitX, orbitZ, maxStep)
        }

        val dx = pos.x - effTargetX
        val dz = pos.z - effTargetZ
        val horizDist = MathUtil.dist2(pos.x, pos.z, effTargetX, effTargetZ)
        if (horizDist < 0.05f) return Vector3f.from(pos.x, newY, pos.z)

        val desired = keepDistanceRange.value
        val tol = keepDistanceTolerance.value
        val diff = horizDist - desired
        if (kotlin.math.abs(diff) <= tol) return Vector3f.from(pos.x, newY, pos.z)

        if (keepDistanceRetreatOnly.value && diff > 0f) return Vector3f.from(pos.x, newY, pos.z)

        val dirX = dx / horizDist; val dirZ = dz / horizDist
        val correction = (-diff).coerceIn(-maxStep, maxStep)

        return Vector3f.from(pos.x + dirX * correction, newY, pos.z + dirZ * correction)
    }

    private fun stepToward(pos: Vector3f, newY: Float, targetX: Float, targetZ: Float, maxStep: Float): Vector3f {
        val dx = targetX - pos.x; val dz = targetZ - pos.z
        val dist = MathUtil.dist2(pos.x, pos.z, targetX, targetZ)
        if (dist < 0.05f) return Vector3f.from(pos.x, newY, pos.z)
        val step = dist.coerceAtMost(maxStep)
        return Vector3f.from(pos.x + (dx / dist) * step, newY, pos.z + (dz / dist) * step)
    }

    private fun EntityTracker.TrackedEntity.isLikelyBot() = name.isBlank() || uniqueId == 0L
}