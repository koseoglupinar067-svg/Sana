package com.noxnoclient.module.visual

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.InventoryUtil
import com.noxnoclient.utils.WorldBlockTracker
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.packet.MobEquipmentPacket

/**
 * While holding an apple, selects a trident in water/rain/snow and a sword
 * while airborne or inside a solid block. The module is independent and lives
 * in the Visual category as requested.
 */
class S4Switch : BaseModule(
    name = "S4Switch",
    category = ModuleCategory.VISUAL,
    description = "Switches apple to trident in water/rain/snow and sword in air/blocks"
) {
    private val appleMode = bool("Apple Trigger", true)
    private val tridentId = string("Trident ID", "minecraft:trident")
    private val swordId = string("Sword ID", "")
    private val switchDelay = int("Switch Delay (ms)", 120, 40, 1000)
    private val switchBack = bool("Switch Back", false)

    private var lastSwitchMs = 0L
    private var lastAppleSlot = -1
    private var lastSwitchedSlot = -1

    private fun isApple(slot: Int): Boolean {
        val id = InventoryUtil.resolveIdentifier(EntityTracker.getInventoryItem(slot) ?: return false) ?: return false
        return id == "minecraft:golden_apple" || id == "minecraft:enchanted_golden_apple"
    }

    private fun isInsideSolidBlock(): Boolean {
        val x = EntityTracker.selfX.toInt()
        val y = (EntityTracker.selfY + 1.5f).toInt()
        val z = EntityTracker.selfZ.toInt()
        val id = WorldBlockTracker.getBlockIdentifier(x, y, z) ?: return false
        return id !in setOf(
            "minecraft:air", "minecraft:void_air", "minecraft:cave_air",
            "minecraft:water", "minecraft:flowing_water", "minecraft:lava",
            "minecraft:flowing_lava"
        )
    }

    private fun isSnowingAroundPlayer(): Boolean {
        val x = EntityTracker.selfX.toInt()
        val y = EntityTracker.selfY.toInt()
        val z = EntityTracker.selfZ.toInt()
        for (dy in 0..2) {
            val id = WorldBlockTracker.getBlockIdentifier(x, y + dy, z) ?: continue
            if (id.contains("snow")) return true
        }
        return false
    }

    private fun findHotbarItem(id: String): Int {
        if (id.isBlank()) return -1
        for (slot in 0..8) {
            val item = EntityTracker.getInventoryItem(slot) ?: continue
            if (InventoryUtil.resolveIdentifier(item) == id) return slot
        }
        return -1
    }

    private fun findSword(): Int {
        if (swordId.value.isNotBlank()) return findHotbarItem(swordId.value)
        for (slot in 0..8) {
            val id = InventoryUtil.resolveIdentifier(EntityTracker.getInventoryItem(slot) ?: continue) ?: continue
            if (id.endsWith("_sword")) return slot
        }
        return -1
    }

    private fun switchTo(session: NoxNoRelaySession, slot: Int) {
        val item = EntityTracker.getInventoryItem(slot) ?: ItemData.AIR
        val packet = MobEquipmentPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            containerId = 0
            hotbarSlot = slot
            inventorySlot = slot
            this.item = item
        }
        // Send the temporary selection only to the server. Do NOT mirror the
        // equipment packet back to the client and do NOT mutate selfHotbarSlot;
        // this keeps the player's visible hotbar/selected slot unchanged.
        session.serverBound(packet)
        lastSwitchMs = System.currentTimeMillis()
        lastSwitchedSlot = slot
    }

    override fun onEnable() {
        super.onEnable()
        lastSwitchMs = 0L
        lastAppleSlot = -1
        lastSwitchedSlot = -1
    }

    override fun onDisable() {
        super.onDisable()
        if (switchBack.value && lastAppleSlot >= 0) {
            PacketEventBus.currentSession?.let { switchTo(it, lastAppleSlot) }
        }
        lastAppleSlot = -1
        lastSwitchedSlot = -1
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled || !appleMode.value) return
        val current = EntityTracker.selfHotbarSlot
        if (!isApple(current)) {
            if (lastAppleSlot >= 0 && current != lastSwitchedSlot) lastAppleSlot = -1
            return
        }
        lastAppleSlot = current
        if (System.currentTimeMillis() - lastSwitchMs < switchDelay.value) return

        val tridentEnvironment = EntityTracker.selfInWater || EntityTracker.selfIsRaining || isSnowingAroundPlayer()
        val targetSlot = if (tridentEnvironment) findHotbarItem(tridentId.value) else {
            // Air and being inside a block both use the sword; grounded normal play
            // also falls back to the sword when no trident environment is active.
            findSword()
        }
        if (targetSlot >= 0 && targetSlot != current) {
            PacketEventBus.currentSession?.let { switchTo(it, targetSlot) }
        }
    }
}
