package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.*
import com.noxnoclient.utils.InventoryUtil
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MobEquipmentPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

class AutoGap : BaseModule(
    name        = "AutoGap",
    category    = ModuleCategory.COMBAT,
    description = "Auto-eats enchanted golden apple / golden apple when health drops below threshold"
) {
    private val healthThreshold = float("Health Threshold", 14f, 1f, 20f)
    private val preferEgap      = bool ("Prefer EGap",      true)
    private val cooldownMs      = int  ("Cooldown (ms)",     500, 100, 5000)
    private val shortcut        = bool ("Shortcut",          false)

    private val EGAP_ID  = "minecraft:enchanted_golden_apple"
    private val GAP_ID   = "minecraft:golden_apple"

    @Volatile private var lastEatMs    = 0L
    @Volatile private var savedSlot    = -1
    @Volatile private var gapSlot      = -1
    @Volatile private var isEating     = false

    override fun onEnable() {
        super.onEnable()
        lastEatMs = 0L
        savedSlot = -1
        gapSlot   = -1
        isEating  = false
    }

    override fun onDisable() {
        super.onDisable()
        val session = PacketEventBus.currentSession ?: return
        if (savedSlot >= 0 && isEating) {
            switchTo(session, savedSlot)
        }
        isEating  = false
        savedSlot = -1
        gapSlot   = -1
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return

        val hp = EntityTracker.selfHealth
        if (hp > healthThreshold.value) {
            if (isEating) stopEating()
            return
        }

        val now = System.currentTimeMillis()
        if (now - lastEatMs < cooldownMs.value) return

        val session = PacketEventBus.currentSession ?: return

        val found = findGap() ?: return

        lastEatMs = now
        gapSlot   = found
        savedSlot = EntityTracker.selfHotbarSlot
        isEating  = true

        switchTo(session, found)
        startEating(session)
    }

    private fun findGap(): Int? {
        if (preferEgap.value) {
            val e = findInHotbar(EGAP_ID)
            if (e >= 0) return e
        }
        val g = findInHotbar(GAP_ID)
        if (g >= 0) return g
        if (!preferEgap.value) {
            val e = findInHotbar(EGAP_ID)
            if (e >= 0) return e
        }
        return null
    }

    private fun findInHotbar(id: String): Int {
        for (s in 0..8) {
            val item = EntityTracker.getInventoryItem(s) ?: continue
            if (InventoryUtil.resolveIdentifier(item) == id) return s
        }
        return -1
    }

    private fun switchTo(session: com.noxnoclient.core.relay.NoxNoRelaySession, slot: Int) {
        val item = EntityTracker.getInventoryItem(slot) ?: ItemData.AIR
        val pkt = MobEquipmentPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            containerId     = 0
            hotbarSlot      = slot
            inventorySlot   = slot
            this.item       = item
        }
        session.serverBound(pkt)
        session.clientBound(pkt)
    }

    private fun startEating(session: com.noxnoclient.core.relay.NoxNoRelaySession) {
        val item = EntityTracker.getInventoryItem(gapSlot) ?: return
        val tx = InventoryTransactionPacket().apply {
            transactionType  = org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType.ITEM_USE
            actionType       = 0
            hotbarSlot       = gapSlot
            itemInHand       = item
            blockPosition    = org.cloudburstmc.math.vector.Vector3i.ZERO
            blockFace        = -1
            clickPosition    = org.cloudburstmc.math.vector.Vector3f.ZERO
            headPosition     = org.cloudburstmc.math.vector.Vector3f.from(
                EntityTracker.selfX, EntityTracker.selfY + 1.62f, EntityTracker.selfZ)
        }
        session.serverBound(tx)
    }

    private fun stopEating() {
        val session = PacketEventBus.currentSession ?: return
        if (savedSlot >= 0 && savedSlot != gapSlot) switchTo(session, savedSlot)
        isEating  = false
        savedSlot = -1
        gapSlot   = -1
    }
}
