package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.*
import kotlinx.coroutines.launch
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.Ability
import org.cloudburstmc.protocol.bedrock.data.AbilityLayer
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.data.PlayerPermission
import org.cloudburstmc.protocol.bedrock.data.command.CommandPermission
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.SetEntityMotionPacket
import org.cloudburstmc.protocol.bedrock.packet.UpdateAbilitiesPacket
import kotlin.math.cos
import kotlin.math.sin

class MotionFly : BaseModule(
    name        = "MotionFly",
    category    = ModuleCategory.MOVEMENT,
    description = "Motion packet-based flight - Lifeboat Bypass"
) {

    private val horizontalSpeed = float("Horizontal Speed", 1.0f, 0.25f, 3.0f)
    private val verticalSpeed = float("Vertical Speed", 0.8f, 0.25f, 2.0f)
    private val glideSpeed = float("Glide Speed", 0.05f, -0.01f, 0.5f)
    private val bypassMode = bool("Lifeboat Bypass", true)
    private val motionInterval = float("Delay", 100.0f, 50.0f, 200.0f)
    private val shortcut = bool("Shortcut", false)

    @Volatile private var lastMotionTime = 0L
    @Volatile private var jitterState = false
    @Volatile private var canFly = false
    @Volatile private var lastSession: NoxNoRelaySession? = null
    @Volatile private var correctionCooldownUntil = 0L

    private val flyPacket = UpdateAbilitiesPacket().apply {
        playerPermission = PlayerPermission.OPERATOR
        commandPermission = CommandPermission.OWNER
        uniqueEntityId = -1
        abilityLayers.add(AbilityLayer().apply {
            layerType = AbilityLayer.Type.BASE
            abilitiesSet.addAll(Ability.entries.toTypedArray())
            abilityValues.addAll(
                arrayOf(
                    Ability.BUILD,
                    Ability.MINE,
                    Ability.DOORS_AND_SWITCHES,
                    Ability.OPEN_CONTAINERS,
                    Ability.ATTACK_PLAYERS,
                    Ability.ATTACK_MOBS,
                    Ability.OPERATOR_COMMANDS,
                    Ability.MAY_FLY,
                    Ability.FLY_SPEED,
                    Ability.WALK_SPEED
                )
            )
            walkSpeed = 0.1f
            flySpeed = 0.5f
        })
    }

    private val resetPacket = UpdateAbilitiesPacket().apply {
        playerPermission = PlayerPermission.VISITOR
        commandPermission = CommandPermission.ANY
        uniqueEntityId = -1
        abilityLayers.add(AbilityLayer().apply {
            layerType = AbilityLayer.Type.BASE
            abilitiesSet.addAll(Ability.entries.toTypedArray())
            abilityValues.addAll(
                arrayOf(
                    Ability.BUILD,
                    Ability.MINE,
                    Ability.DOORS_AND_SWITCHES,
                    Ability.OPEN_CONTAINERS,
                    Ability.ATTACK_PLAYERS,
                    Ability.ATTACK_MOBS,
                    Ability.OPERATOR_COMMANDS,
                    Ability.FLY_SPEED,
                    Ability.WALK_SPEED
                )
            )
            walkSpeed = 0.1f
            flySpeed = 0.05f
        })
    }

    override fun onEnable() {
        super.onEnable()
        lastMotionTime = 0L
        jitterState = false
        canFly = false
        correctionCooldownUntil = 0L
    }

    override fun onDisable() {
        super.onDisable()
        lastSession?.let { applyFlyAbilities(false, it) }
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        val pkt = event.packet
        if (pkt !is PlayerAuthInputPacket) return
        if (event.direction == PacketEvent.Direction.SERVER_TO_CLIENT) {
            // A server position correction means our locally simulated flight was rejected.
            // Pause motion injection briefly instead of immediately fighting the correction.
            if (event.packet is org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket &&
                (event.packet as org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket).runtimeEntityId == EntityTracker.selfRuntimeId) {
                correctionCooldownUntil = System.currentTimeMillis() + 350L
            }
            return
        }
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        if (System.currentTimeMillis() < correctionCooldownUntil) return

        lastSession = event.session
        applyFlyAbilities(true, event.session)

        val now = System.currentTimeMillis()
        if (now - lastMotionTime < motionInterval.value) return

        val vertical = when {
            pkt.inputData.contains(PlayerAuthInputData.WANT_UP) -> verticalSpeed.value
            pkt.inputData.contains(PlayerAuthInputData.WANT_DOWN) -> -verticalSpeed.value
            bypassMode.value -> -glideSpeed.value.coerceAtLeast(-0.1f)
            else -> glideSpeed.value
        }

        val inputX = pkt.motion.x
        val inputZ = pkt.motion.y

        val yawRad = Math.toRadians(pkt.rotation.y.toDouble()).toFloat()
        val sinYaw = sin(yawRad)
        val cosYaw = cos(yawRad)

        val strafe = inputX * horizontalSpeed.value
        val forward = inputZ * horizontalSpeed.value

        val motionX = (strafe * cosYaw - forward * sinYaw).coerceIn(-horizontalSpeed.value, horizontalSpeed.value)
        val motionZ = (forward * cosYaw + strafe * sinYaw).coerceIn(-horizontalSpeed.value, horizontalSpeed.value)

        val motionPacket = SetEntityMotionPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            motion = Vector3f.from(
                motionX,
                vertical,
                motionZ
            )
        }

        event.session.clientBound(motionPacket)
        lastMotionTime = now
    }

    private fun applyFlyAbilities(enabled: Boolean, session: NoxNoRelaySession) {
        if (canFly == enabled) return
        val id = EntityTracker.selfUniqueId
        flyPacket.uniqueEntityId = id
        resetPacket.uniqueEntityId = id
        session.clientBound(if (enabled) flyPacket else resetPacket)
        canFly = enabled
    }
}