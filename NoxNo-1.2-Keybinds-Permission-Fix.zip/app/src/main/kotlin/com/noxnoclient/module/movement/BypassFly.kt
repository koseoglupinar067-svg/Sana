package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.*
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.data.Ability
import org.cloudburstmc.protocol.bedrock.data.AbilityLayer
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.data.PlayerPermission
import org.cloudburstmc.protocol.bedrock.data.command.CommandPermission
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.RequestAbilityPacket
import org.cloudburstmc.protocol.bedrock.packet.SetEntityMotionPacket
import org.cloudburstmc.protocol.bedrock.packet.UpdateAbilitiesPacket
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class BypassFly : BaseModule(
    name        = "BypassFly",
    category    = ModuleCategory.MOVEMENT,
    description = "Flight with a separate motion profile per environment (Water/Ground/Air/Auto)"
) {
    enum class FlyMode { Water, Ground, Air, Auto }

    private val mode              = enum ("Mode",                 FlyMode.Auto)
    private val horizontalSpeed   = float("Horizontal Speed",     4.0f,  0.5f, 10.0f)
    private val airVerticalSpeed  = float("Air Vertical Speed",   1.6f,  0.2f, 5.0f)
    private val waterVerticalSpeed= float("Water Vertical Speed", 0.9f,  0.1f, 3.0f)
    private val waterBob          = float("Water Bob",            0.02f, 0.0f, 0.1f)
    private val airJitter         = float("Air Jitter",           0.05f, 0.0f, 0.3f)
    private val motionInterval    = int  ("Delay",                 55,   15,  150)
    private val grantAbilities    = bool ("Grant Fly Ability",     true)
    private val accelSmoothing    = bool ("Smooth Acceleration",   true)
    private val pauseOnDamage     = bool ("Pause On Damage",       true)
    private val pauseDurationMs   = int  ("Pause Duration (ms)",   400,  100, 2000)

    private val shortcut          = bool ("Shortcut",              false)

    @Volatile private var lastMotionMs   = 0L
    @Volatile private var abilitiesOn    = false
    @Volatile private var lastSession    : NoxNoRelaySession? = null

    @Volatile private var committedMode    = FlyMode.Air
    @Volatile private var candidateMode    = FlyMode.Air
    @Volatile private var candidateSinceMs = 0L

    @Volatile private var speedFactor = 0f

    @Volatile private var lastKnownHealth = 20f
    @Volatile private var lastDamageMs    = 0L

    override fun onEnable() {
        super.onEnable()
        lastMotionMs     = 0L
        abilitiesOn      = false
        committedMode    = FlyMode.Air
        candidateMode    = FlyMode.Air
        candidateSinceMs = 0L
        speedFactor      = 0f
        lastKnownHealth  = EntityTracker.selfHealth
        lastDamageMs     = 0L

        scope.launch {
            EntityTracker.selfHealthFlow.collect { hp ->
                if (hp < lastKnownHealth - 0.01f) lastDamageMs = System.currentTimeMillis()
                lastKnownHealth = hp
            }
        }
    }

    override fun onDisable() {
        super.onDisable()
        lastSession?.let { applyAbilities(it, false) }
        abilitiesOn = false
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        val pkt = event.packet

        if (abilitiesOn) {
            if (pkt is RequestAbilityPacket && pkt.ability == Ability.FLYING) {
                event.cancel()
                return
            }
            if (pkt is UpdateAbilitiesPacket) {
                event.cancel()
                return
            }
        }

        if (pkt !is PlayerAuthInputPacket) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return

        lastSession = event.session

        val now = System.currentTimeMillis()

        if (pauseOnDamage.value && now - lastDamageMs < pauseDurationMs.value) {

            return
        }

        val effectiveMode = resolveMode(now)

        val wantAbilities = grantAbilities.value && effectiveMode != FlyMode.Ground
        if (wantAbilities != abilitiesOn) applyAbilities(event.session, wantAbilities)

        if (now - lastMotionMs < motionInterval.value) return
        lastMotionMs = now

        val yaw    = Math.toRadians(pkt.rotation.y.toDouble()).toFloat()
        val sinYaw = sin(yaw)
        val cosYaw = cos(yaw)

        val inputX = pkt.motion.x
        val inputZ = pkt.motion.y
        val hasInput = inputX != 0f || inputZ != 0f

        if (accelSmoothing.value) {

            val target = if (hasInput) 1f else 0f
            val rate   = (motionInterval.value / 250f).coerceIn(0.05f, 0.9f)
            speedFactor += (target - speedFactor) * rate
        } else {
            speedFactor = if (hasInput) 1f else 0f
        }

        val strafe  = inputX * horizontalSpeed.value * speedFactor
        val forward = inputZ * horizontalSpeed.value * speedFactor
        val motionX = strafe * cosYaw - forward * sinYaw
        val motionZ = forward * cosYaw + strafe * sinYaw

        val wantUp   = pkt.inputData.contains(PlayerAuthInputData.WANT_UP)
        val wantDown = pkt.inputData.contains(PlayerAuthInputData.WANT_DOWN)

        val motionY = when (effectiveMode) {
            FlyMode.Ground -> 0f
            FlyMode.Water  -> when {
                wantUp   ->  waterVerticalSpeed.value
                wantDown -> -waterVerticalSpeed.value
                else     -> noise(waterBob.value)
            }
            FlyMode.Air, FlyMode.Auto -> when {
                wantUp   ->  airVerticalSpeed.value
                wantDown -> -airVerticalSpeed.value
                else     -> noise(airJitter.value)
            }
        }

        val motionPacket = SetEntityMotionPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            motion = Vector3f.from(motionX, motionY, motionZ)
        }
        event.session.clientBound(motionPacket)
    }

    private fun resolveMode(now: Long): FlyMode {
        if (mode.value != FlyMode.Auto) {
            committedMode = mode.value
            return committedMode
        }

        val raw = when {
            EntityTracker.selfInWater  -> FlyMode.Water
            EntityTracker.selfOnGround -> FlyMode.Ground
            else                       -> FlyMode.Air
        }

        if (raw != candidateMode) {
            candidateMode = raw
            candidateSinceMs = now
        }
        if (now - candidateSinceMs >= 120L) committedMode = candidateMode

        return committedMode
    }

    private fun noise(magnitude: Float): Float =
        if (magnitude <= 0f) 0f else (Random.nextFloat() * 2f - 1f) * magnitude

    private fun applyAbilities(session: NoxNoRelaySession, enabled: Boolean) {
        val packet = UpdateAbilitiesPacket().apply {
            playerPermission  = if (enabled) PlayerPermission.OPERATOR else PlayerPermission.VISITOR
            commandPermission = if (enabled) CommandPermission.OWNER  else CommandPermission.ANY
            uniqueEntityId    = EntityTracker.selfUniqueId
            abilityLayers.add(AbilityLayer().apply {
                layerType = AbilityLayer.Type.BASE
                abilitiesSet.addAll(Ability.entries.toTypedArray())

                val values = mutableListOf(
                    Ability.BUILD, Ability.MINE, Ability.DOORS_AND_SWITCHES,
                    Ability.OPEN_CONTAINERS, Ability.ATTACK_PLAYERS, Ability.ATTACK_MOBS,
                    Ability.FLY_SPEED, Ability.WALK_SPEED, Ability.VERTICAL_FLY_SPEED
                )
                if (enabled) {
                    values += Ability.MAY_FLY
                    values += Ability.FLYING
                }
                abilityValues.addAll(values.toTypedArray())

                walkSpeed        = 0.1f
                flySpeed         = if (enabled) 0.3f else 0.05f
                verticalFlySpeed = if (enabled) 0.25f else 0.05f
            })
        }
        session.clientBound(packet)
        abilitiesOn = enabled
    }
}
