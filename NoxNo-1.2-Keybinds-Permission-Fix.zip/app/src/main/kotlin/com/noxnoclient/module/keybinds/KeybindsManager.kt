package com.noxnoclient.module.keybinds

import android.view.KeyEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleManager
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Thread-safe registry shared by the dashboard, overlay and accessibility service. */
data class Keybind(
    val id: String,
    val module: BaseModule,
    val keyCode: Int,
    val requiresCtrl: Boolean = false,
    val requiresShift: Boolean = false,
    val requiresAlt: Boolean = false,
    val isActive: Boolean = true
)

object KeybindsManager {
    private val keybinds = ConcurrentHashMap<String, Keybind>()
    private val listeners = mutableListOf<(Keybind) -> Unit>()
    private val _captureId = MutableStateFlow<String?>(null)
    val captureId: StateFlow<String?> = _captureId.asStateFlow()

    @Synchronized
    fun registerKeybind(
        keybindId: String,
        module: BaseModule,
        keyCode: Int,
        requiresCtrl: Boolean = false,
        requiresShift: Boolean = false,
        requiresAlt: Boolean = false
    ): Boolean {
        val keybind = Keybind(keybindId, module, keyCode, requiresCtrl, requiresShift, requiresAlt)
        return keybinds.putIfAbsent(keybindId, keybind) == null
    }

    fun updateKeybind(
        keybindId: String,
        keyCode: Int,
        requiresCtrl: Boolean = false,
        requiresShift: Boolean = false,
        requiresAlt: Boolean = false,
        active: Boolean? = null
    ): Boolean {
        val old = keybinds[keybindId] ?: return false
        keybinds[keybindId] = old.copy(
            keyCode = keyCode,
            requiresCtrl = requiresCtrl,
            requiresShift = requiresShift,
            requiresAlt = requiresAlt,
            isActive = active ?: old.isActive
        )
        return true
    }

    fun removeKeybind(keybindId: String): Boolean = keybinds.remove(keybindId) != null
    fun getKeybind(keybindId: String): Keybind? = keybinds[keybindId]
    fun getAllKeybinds(): Map<String, Keybind> = keybinds.toMap()

    fun setKeybindActive(keybindId: String, active: Boolean): Boolean {
        val old = keybinds[keybindId] ?: return false
        keybinds[keybindId] = old.copy(isActive = active)
        return true
    }

    fun handle(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount != 0) return false
        return handleKeyCode(event.keyCode, event.isCtrlPressed, event.isShiftPressed, event.isAltPressed)
    }

    fun handleKeyCode(
        keyCode: Int,
        ctrl: Boolean,
        shift: Boolean,
        alt: Boolean
    ): Boolean {
        val match = keybinds.values.firstOrNull {
            it.isActive &&
                it.keyCode == keyCode &&
                it.requiresCtrl == ctrl &&
                it.requiresShift == shift &&
                it.requiresAlt == alt
        } ?: return false

        // KeybindsModule itself is the global on/off switch. Do not let a disabled
        // controller consume a key that should continue into Minecraft/chat.
        val controller = ModuleManager.byName("Keybinds")
        if (controller?.isEnabled == false) return false
        if (controller?.getSettingValue<Boolean>("Global Keybinds") == false) return false

        ModuleManager.toggle(match.module)
        listeners.toList().forEach { listener ->
            try { listener(match) } catch (_: Exception) { }
        }
        return true
    }

    fun addKeyListener(listener: (Keybind) -> Unit) {
        synchronized(listeners) { listeners += listener }
    }

    fun removeKeyListener(listener: (Keybind) -> Unit) {
        synchronized(listeners) { listeners -= listener }
    }

    fun beginCapture(keybindId: String) { _captureId.value = keybindId }
    fun cancelCapture() { _captureId.value = null }

    fun captureKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount != 0) return false
        val id = _captureId.value ?: return false
        if (event.keyCode == KeyEvent.KEYCODE_ESCAPE) {
            _captureId.value = null
            return true
        }

        val ctrl = event.isCtrlPressed
        val shift = event.isShiftPressed
        val alt = event.isAltPressed

        // Keep each shortcut unique. A newly assigned combination wins and the
        // old shortcut is disabled instead of leaving an ambiguous toggle.
        keybinds.values
            .filter { it.id != id && it.keyCode == event.keyCode &&
                it.requiresCtrl == ctrl && it.requiresShift == shift && it.requiresAlt == alt }
            .forEach { setKeybindActive(it.id, false) }

        val updated = updateKeybind(id, event.keyCode, ctrl, shift, alt, true)
        _captureId.value = null
        return updated
    }

    fun clearAllKeybinds() = keybinds.clear()
}
