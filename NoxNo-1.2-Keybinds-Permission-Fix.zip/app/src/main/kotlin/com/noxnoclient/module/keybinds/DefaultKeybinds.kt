package com.noxnoclient.module.keybinds

import android.content.Context
import android.view.KeyEvent
import com.noxnoclient.config.KeybindsConfig
import com.noxnoclient.module.ModuleManager

object DefaultKeybinds {
    private fun bind(id: String, moduleName: String, key: Int, ctrl: Boolean = true, shift: Boolean = false, alt: Boolean = false) {
        ModuleManager.byName(moduleName)?.let {
            KeybindsManager.registerKeybind(id, it, key, ctrl, shift, alt)
        }
    }

    fun init(context: Context) {
        bind("killaura_toggle", "KillAura", KeyEvent.KEYCODE_K)
        bind("autototem_toggle", "AutoTotem", KeyEvent.KEYCODE_T)
        bind("crystalaura_toggle", "CrystalAura", KeyEvent.KEYCODE_C)
        bind("bedaura_toggle", "BedAura", KeyEvent.KEYCODE_B)
        bind("anchoraura_toggle", "AnchorAura", KeyEvent.KEYCODE_O)
        bind("speed_toggle", "Speed", KeyEvent.KEYCODE_S)
        bind("motionfly_toggle", "MotionFly", KeyEvent.KEYCODE_F)
        bind("noclip_toggle", "NoClip", KeyEvent.KEYCODE_N)
        bind("jetpack_toggle", "Jetpack", KeyEvent.KEYCODE_J)
        bind("targetesp_toggle", "TargetESP", KeyEvent.KEYCODE_E)
        bind("fullbright_toggle", "FullBright", KeyEvent.KEYCODE_L)
        bind("arraylist_toggle", "ArrayList", KeyEvent.KEYCODE_G)
        bind("chatspammer_toggle", "ChatSpammer", KeyEvent.KEYCODE_S, ctrl = false, alt = true)
        bind("popcounter_toggle", "PopCounter", KeyEvent.KEYCODE_P, ctrl = false, alt = true)
        KeybindsConfig(context).load()
    }
}
