package com.noxnoclient.module.misc

import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.packet.TextPacket
import kotlin.random.Random

class ChatAdvertiser : BaseModule(
    name        = "Advertiser",
    category    = ModuleCategory.MISC,
    description = "Drops a PVP/1v1 call-out into chat at set intervals"
) {
    companion object {
        private const val JUNK_CHARS = "abcdefghjklmnopqrstuvwxyz0123456789"
        private val JUNK_RANGE = 8..16

        private val MESSAGES = listOf(
            "> @here tpa pvp 1v1 who wants smoke | {junk} | NoxNo Client v1.0",
            "> @here 1v1 tpa pvp all ez | {junk} | NoxNo Client v1.0",
            "> @here tpa to pvp nns | {junk} | NoxNo Client v1.0",
            "> @here tpa for pvp all skill issue if you decline | {junk} | NoxNo Client v1.0",
            "> @here anyone tpa pvp cant be that scared | {junk} | NoxNo Client v1.0",
            "> @here tpa pvp free win here | {junk} | NoxNo Client v1.0",
            "> @here tpa 1v1 no crystal easy | {junk} | NoxNo Client v1.0",
            "> @here tpa pvp lets go who wants smoke | {junk} | NoxNo Client v1.0",
            "> @here tpa all cracked pvpers welcome | {junk} | NoxNo Client v1.0",
            "> @here tpa pvp best client wins obviously | {junk} | NoxNo Client v1.0",
            "> @here tpa 1v1 quick fight nobody scared right | {junk} | NoxNo Client v1.0",
            "> @here tpa pvp bring your best totem | {junk} | NoxNo Client v1.0",
            "> @here NoxNo Client — best mobile PVP client | {junk}",
            "> @here running NoxNo Client rn, tpa if you dare | {junk}"
        )
    }

    private val intervalMs = int("Interval (ms)", 25_000, 5_000, 120_000)
    private val shortcut   = bool("Shortcut", false)

    private var tickJob: Job? = null
    @Volatile private var activeSession: NoxNoRelaySession? = null

    override fun onEnable() {
        super.onEnable()
        tickJob = scope.launch {
            while (currentCoroutineContext().isActive) {
                delay(intervalMs.value.toLong())
                sendAd()
            }
        }
    }

    override fun onDisable() {
        tickJob?.cancel()
        tickJob = null
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        activeSession = event.session
    }

    private fun sendAd() {
        val session = activeSession ?: return
        if (!session.isServerReady) return
        val text = MESSAGES[Random.nextInt(MESSAGES.size)].replace("{junk}", randomJunk())
        runCatching { session.sendToServer(buildTextPacket(text)) }
    }

    private fun buildTextPacket(message: String): TextPacket = TextPacket().apply {
        type               = TextPacket.Type.CHAT
        isNeedsTranslation = false
        sourceName         = "__noxno_internal__"
        xuid               = ""
        platformChatId     = ""
        setMessage(message)
        setFilteredMessage("")
    }

    private fun randomJunk(): String {
        val len = Random.nextInt(JUNK_RANGE.first, JUNK_RANGE.last + 1)
        return buildString(len) { repeat(len) { append(JUNK_CHARS[Random.nextInt(JUNK_CHARS.length)]) } }
    }
}
