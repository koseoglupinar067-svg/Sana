package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.module.social.isFriendEntity
import com.noxnoclient.utils.InventoryUtil
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.WorldBlockTracker
import kotlinx.coroutines.*
import org.cloudburstmc.math.vector.Vector3i
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.floor

class AnchorAura : BaseModule(
    name        = "AnchorAura",
    category    = ModuleCategory.COMBAT,
    description = "Places a respawn anchor next to the target, charges it, and detonates it outside the Nether"
) {
    companion object {
        private const val ACTIVATE_DELAY_MS      = 60L
        private const val VERIFY_RETRY_WINDOW_MS = 150L
        private const val VERIFY_CHECK_EVERY_MS  = 20L

        private const val TARGET_SCAN_INTERVAL_MS = 80L

        private val NON_SOLID = setOf(
            "minecraft:air", "minecraft:water", "minecraft:flowing_water",
            "minecraft:lava", "minecraft:flowing_lava",
            "minecraft:void_air", "minecraft:cave_air"
        )

        private const val ANCHOR    = "minecraft:respawn_anchor"
        private const val GLOWSTONE = "minecraft:glowstone"

        private val FACE_OFFSETS = listOf(
            1 to Triple(0, 1, 0),
            2 to Triple(0, 0, -1),
            3 to Triple(0, 0, 1),
            4 to Triple(-1, 0, 0),
            5 to Triple(1, 0, 0),
            0 to Triple(0, -1, 0)
        )
    }

    private val targetRange      = int  ("Target Range",        16,  2,   16)
    private val friendSkip       = bool ("Friend Skip",         true)

    private val placeRange       = int  ("Place Range",         16,  2,   16)
    private val noSwitch         = bool ("No Switch",           true)

    private val cooldownMs       = int  ("Cooldown (ms)",        20,  20,  5000)
    private val requireNotNether = bool ("Require Not-Nether",   true)
    private val shortcut         = bool ("Shortcut",             false)
    private val maxAnchors       = int  ("Max Anchors",          5,   1,    5)
    private val tickMs           = int  ("Tick Speed (ms)",      10,  10,  150)
    private val packetGapMs      = int  ("Min Packet Gap (ms)",  20,  20,  500)

    private val forceMode         = bool ("Force",                false)

    private val smartDetonate     = bool ("Smart Detonate",       true)
    private val smartDetonateRange = float("Smart Detonate Range", 5f,  1f,  10f)
    private val smartDetonateMaxWaitMs = int("Smart Detonate Max Wait", 600, 0, 3000)

    private enum class Phase {
        PLACED,
        CHARGED
    }

    private data class Attempt(
        val anchorPos: Vector3i,
        val phase: Phase,
        val armedAt: Long,
        val verifyDeadline: Long = 0L,
        val targetId: Long = -1L,
        val nextCheckAt: Long = 0L
    )

    private val activeAttempts = CopyOnWriteArrayList<Attempt>()

    @Volatile
    private var lastAttemptMs = 0L

    @Volatile
    private var lastPacketSentMs = 0L

    private var tickJob: Job? = null

    override fun onEnable() {
        super.onEnable()

        activeAttempts.clear()
        lastPacketSentMs = 0L

        tickJob?.cancel()
        tickJob = scope.launch {
            while (currentCoroutineContext().isActive) {
                if (isEnabled) {
                    tick()
                }

                delay(tickMs.value.toLong())
            }
        }
    }

    override fun onDisable() {
        tickJob?.cancel()
        tickJob = null

        activeAttempts.clear()

        super.onDisable()
    }

    private fun tryConsumePacketSlot(): Boolean {
        val now = System.currentTimeMillis()

        if (now - lastPacketSentMs < packetGapMs.value) {
            return false
        }

        lastPacketSentMs = now
        return true
    }

    private fun tick() {
        if (requireNotNether.value && EntityTracker.selfDimension == 1) {
            return
        }

        val session = PacketEventBus.currentSession ?: return
        val now = System.currentTimeMillis()

        for (attempt in activeAttempts) {
            if (now - attempt.armedAt < ACTIVATE_DELAY_MS) {
                continue
            }

            when (attempt.phase) {
                Phase.PLACED -> {
                    if (now < attempt.nextCheckAt) {
                        continue
                    }

                    when (verifyPlaced(attempt)) {
                        VerifyResult.CONFIRMED -> {
                            chargeAnchor(session, attempt)
                        }

                        VerifyResult.REJECTED -> {
                            activeAttempts.remove(attempt)
                        }

                        VerifyResult.PENDING -> {
                            activeAttempts.remove(attempt)
                            activeAttempts.add(
                                attempt.copy(
                                    nextCheckAt = now + VERIFY_CHECK_EVERY_MS
                                )
                            )
                        }
                    }
                }

                Phase.CHARGED -> {
                    if (smartDetonate.value) {
                        val elapsedSinceCharge = now - attempt.armedAt
                        if (elapsedSinceCharge < smartDetonateMaxWaitMs.value) {
                            val targetEntity = if (attempt.targetId >= 0L) EntityTracker.getById(attempt.targetId) else null
                            if (targetEntity != null) {
                                val centerX = attempt.anchorPos.x + 0.5f
                                val centerY = attempt.anchorPos.y + 0.5f
                                val centerZ = attempt.anchorPos.z + 0.5f
                                val distToTarget = MathUtil.dist3(
                                    centerX, centerY, centerZ,
                                    targetEntity.x, targetEntity.y + 0.9f, targetEntity.z
                                )
                                if (distToTarget > smartDetonateRange.value) {
                                    continue
                                }
                            }
                        }
                    }

                    if (!tryConsumePacketSlot()) {
                        continue
                    }

                    InventoryUtil.sendInteract(
                        session,
                        attempt.anchorPos,
                        ANCHOR
                    )

                    activeAttempts.remove(attempt)
                }
            }
        }

        if (activeAttempts.size >= maxAnchors.value) {
            return
        }

        if (now - lastAttemptMs < cooldownMs.value) {
            return
        }

        val target = nearestEnemy() ?: return
        attemptPlace(session, target)
    }
    private fun pickOpenFace(pos: Vector3i): Int {
        if (!WorldBlockTracker.hasData(pos.x, pos.y, pos.z)) {
            return 1
        }

        for ((face, offset) in FACE_OFFSETS) {
            val nx = pos.x + offset.first
            val ny = pos.y + offset.second
            val nz = pos.z + offset.third

            val id = WorldBlockTracker.getBlockIdentifier(nx, ny, nz)
                ?: continue

            if (id in NON_SOLID) {
                return face
            }
        }

        return 1
    }

    private fun chargeAnchor(
        session: NoxNoRelaySession,
        attempt: Attempt
    ) {
        if (!tryConsumePacketSlot()) {
            activeAttempts.remove(attempt)
            activeAttempts.add(
                attempt.copy(
                    nextCheckAt = System.currentTimeMillis() + VERIFY_CHECK_EVERY_MS
                )
            )
            return
        }

        val glowstone = InventoryUtil.prepareItemForUse(
            session = session,
            identifier = GLOWSTONE,
            noSwitch = noSwitch.value
        ) ?: run {
            activeAttempts.remove(attempt)
            return
        }

        val success = InventoryUtil.sendPlacementUseRaw(
            session = session,
            prepared = glowstone,
            blockPos = attempt.anchorPos,
            blockId = ANCHOR,
            blockFace = pickOpenFace(attempt.anchorPos)
        )

        InventoryUtil.revert(session, glowstone)

        activeAttempts.remove(attempt)

        if (success) {
            activeAttempts.add(
                Attempt(
                    anchorPos = attempt.anchorPos,
                    phase = Phase.CHARGED,
                    armedAt = System.currentTimeMillis(),
                    targetId = attempt.targetId
                )
            )
        }
    }

    private fun nearestEnemy(): EntityTracker.TrackedEntity? {
        if (EntityTracker.selfRuntimeId <= 0L) {
            return null
        }

        val selfX = EntityTracker.selfX
        val selfY = EntityTracker.selfY
        val selfZ = EntityTracker.selfZ

        return EntityTracker
            .getPlayers(targetRange.value.toFloat())
            .asSequence()
            .filter { it.runtimeId != EntityTracker.selfRuntimeId }
            .filter { !friendSkip.value || !it.isFriendEntity }
            .filter {
                MathUtil.dist3(
                    it.x,
                    it.y,
                    it.z,
                    selfX,
                    selfY,
                    selfZ
                ) <= targetRange.value.toFloat() + 1f
            }
            .minByOrNull {
                MathUtil.dist3sq(
                    it.x,
                    it.y,
                    it.z,
                    selfX,
                    selfY,
                    selfZ
                )
            }
    }

    private fun findPlacementSpot(
        targetX: Int,
        targetY: Int,
        targetZ: Int,
        occupied: Set<Vector3i>
    ): Pair<Vector3i, String>? {
        var best: Pair<Vector3i, String>? = null
        var bestDistanceSq = Int.MAX_VALUE
        var bestPlayerDistSq = Float.MAX_VALUE

        val selfX = EntityTracker.selfX
        val selfY = EntityTracker.selfY
        val selfZ = EntityTracker.selfZ

        for (dy in -2..2) {
            for (dx in -1..1) {
                for (dz in -1..1) {
                    val px = targetX + dx
                    val py = targetY + dy
                    val pz = targetZ + dz

                    if (!WorldBlockTracker.hasData(px, py, pz)) {
                        continue
                    }

                    val spotId =
                        WorldBlockTracker.getBlockIdentifier(px, py, pz)
                            ?: "minecraft:air"

                    if (spotId !in NON_SOLID) {
                        continue
                    }

                    val maxBelowDepth = 4
                    var belowId: String? = null
                    var belowFoundAt = 0

                    for (depth in 1..maxBelowDepth) {
                        val belowY = py - depth

                        if (!WorldBlockTracker.hasData(px, belowY, pz)) {
                            continue
                        }

                        val id = WorldBlockTracker.getBlockIdentifier(
                            px,
                            belowY,
                            pz
                        ) ?: continue

                        if (id in NON_SOLID) {
                            continue
                        }

                        belowId = id
                        belowFoundAt = depth
                        break
                    }

                    if (belowId == null) {
                        continue
                    }

                    val anchorY = py - belowFoundAt + 1

                    if (Vector3i.from(px, anchorY, pz) in occupied) {
                        continue
                    }

                    val distanceSq =
                        dx * dx +
                        dy * dy +
                        dz * dz +
                        (belowFoundAt - 1) * (belowFoundAt - 1)

                    val playerDistSq = MathUtil.dist3sq(
                        px + 0.5f, anchorY + 0.5f, pz + 0.5f,
                        selfX, selfY, selfZ
                    )

                    val better = distanceSq < bestDistanceSq ||
                        (distanceSq == bestDistanceSq && playerDistSq < bestPlayerDistSq)

                    if (better) {
                        bestDistanceSq = distanceSq
                        bestPlayerDistSq = playerDistSq

                        best = Vector3i.from(px, anchorY, pz) to belowId
                    }
                }
            }
        }

        return best
    }

    private fun attemptPlace(
        session: NoxNoRelaySession,
        target: EntityTracker.TrackedEntity
    ) {
        val targetX = floor(target.x).toInt()
        val targetY = floor(target.y).toInt()
        val targetZ = floor(target.z).toInt()

        if (
            kotlin.math.abs(targetX) > 30_000_000 ||
            kotlin.math.abs(targetZ) > 30_000_000
        ) {
            return
        }

        val occupied = activeAttempts.mapTo(HashSet()) { it.anchorPos }

        val candidate = findPlacementSpot(
            targetX,
            targetY,
            targetZ,
            occupied
        ) ?: if (forceMode.value) {

            Vector3i.from(targetX, targetY, targetZ) to "minecraft:obsidian"
        } else {
            return
        }

        val anchorPos = candidate.first
        val belowBlock = candidate.second

        val centerX = anchorPos.x + 0.5f
        val centerY = anchorPos.y + 0.5f
        val centerZ = anchorPos.z + 0.5f

        val distance = MathUtil.dist3(
            centerX,
            centerY,
            centerZ,
            EntityTracker.selfX,
            EntityTracker.selfY + 1.62f,
            EntityTracker.selfZ
        )

        if (distance > placeRange.value && !forceMode.value) {
            return
        }

        if (!tryConsumePacketSlot()) {
            return
        }

        val prepared = InventoryUtil.prepareItemForUse(
            session = session,
            identifier = ANCHOR,
            noSwitch = noSwitch.value
        ) ?: return

        lastAttemptMs = System.currentTimeMillis()

        val belowPos = Vector3i.from(
            anchorPos.x,
            anchorPos.y - 1,
            anchorPos.z
        )

        val success = InventoryUtil.sendPlacementUseRaw(
            session = session,
            prepared = prepared,
            blockPos = belowPos,
            blockId = belowBlock,
            blockFace = 1
        )

        InventoryUtil.revert(session, prepared)

        if (!success) {
            return
        }

        val armedAt = System.currentTimeMillis()

        activeAttempts.add(
            Attempt(
                anchorPos = anchorPos,
                phase = Phase.PLACED,
                armedAt = armedAt,
                verifyDeadline = armedAt +
                    ACTIVATE_DELAY_MS +
                    VERIFY_RETRY_WINDOW_MS,
                targetId = target.runtimeId,
                nextCheckAt = armedAt + ACTIVATE_DELAY_MS
            )
        )
    }

    private enum class VerifyResult {
        CONFIRMED,
        REJECTED,
        PENDING
    }

    private fun verifyPlaced(
        attempt: Attempt
    ): VerifyResult {
        if (forceMode.value) return VerifyResult.CONFIRMED

        val now = System.currentTimeMillis()

        if (
            !WorldBlockTracker.hasData(
                attempt.anchorPos.x,
                attempt.anchorPos.y,
                attempt.anchorPos.z
            )
        ) {

            return if (now < attempt.verifyDeadline) {
                VerifyResult.PENDING
            } else {
                VerifyResult.CONFIRMED
            }
        }

        val id = WorldBlockTracker.getBlockIdentifier(
            attempt.anchorPos.x,
            attempt.anchorPos.y,
            attempt.anchorPos.z
        )

        if (id == ANCHOR) {
            return VerifyResult.CONFIRMED
        }

        if (id == null || id in NON_SOLID) {
            return if (now < attempt.verifyDeadline) {
                VerifyResult.PENDING
            } else {
                VerifyResult.CONFIRMED
            }
        }

        return VerifyResult.REJECTED
    }
}