package com.noxnoclient.module.combat

import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

class AntiCrystal : BaseModule(
    name        = "AntiCrystal",
    category    = ModuleCategory.COMBAT,
    description = "Reports a lowered position to the server to reduce end crystal explosion damage"
) {
    private val yLevel   = float("Y Level", 0.4f, 0.1f, 1.61f)
    private val shortcut = bool ("Shortcut", false)

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return

        val pkt = event.packet
        if (pkt !is PlayerAuthInputPacket) return

        pkt.position = pkt.position.add(0f, -yLevel.value, 0f)
        event.cancelAndReplace(pkt)
    }
}
