package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.module.social.isFriendEntity
import com.noxnoclient.utils.InventoryUtil
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.WorldBlockTracker
import org.cloudburstmc.math.vector.Vector3i
import kotlin.math.floor

class BedAura : BaseModule(
    name        = "BedAura",
    category    = ModuleCategory.COMBAT,
    description = "Places a bed next to the target and detonates it (Nether/End)"
) {
    companion object {
        private const val TICK_MS           = 50L
        private const val ACTIVATE_DELAY_MS = 180L

        private val NEIGHBOR_OFFSETS = listOf(
            Triple(1, 0, 0), Triple(-1, 0, 0),
            Triple(0, 0, 1), Triple(0, 0, -1)
        )
    }

    private val targetRange  = int("Target Range", 8, 2, 16)
    private val friendSkip   = bool("Friend Skip", true)
    private val placeRange   = int("Place Range", 6, 2, 12)
    private val bedIdentifier = string("Bed", "minecraft:red_bed")
    private val noSwitch      = bool("No Switch", true)
    private val cooldownMs    = int("Cooldown (ms)", 1500, 200, 5000)
    private val requireNetherOrEnd = bool("Require Nether/End", true)
    private val shortcut = bool("Shortcut", false)

    private val NON_SOLID = setOf(
        "minecraft:air", "minecraft:water", "minecraft:flowing_water",
        "minecraft:lava", "minecraft:flowing_lava",
        "minecraft:void_air", "minecraft:cave_air"
    )

    private data class Attempt(val bedPos: Vector3i, val armedAt: Long)

    @Volatile private var active: Attempt? = null
    @Volatile private var lastAttemptMs = 0L
    @Volatile private var tickJob: kotlinx.coroutines.Job? = null

    override fun onEnable() {
        super.onEnable()
        active = null
        tickJob?.cancel()
        tickJob = launchTickLoop(TICK_MS) { tick() }
    }

    override fun onDisable() {
        tickJob?.cancel(); tickJob = null
        super.onDisable()
        active = null
    }

    private fun tick() {
        if (requireNetherOrEnd.value && EntityTracker.selfDimension == 0) return
        val session = PacketEventBus.currentSession ?: return

        active?.let { a ->
            if (System.currentTimeMillis() - a.armedAt >= ACTIVATE_DELAY_MS) {
                InventoryUtil.sendInteract(session, a.bedPos, bedIdentifier.value)
                active = null
            }
            return
        }

        val now = System.currentTimeMillis()
        if (now - lastAttemptMs < cooldownMs.value) return

        val target = nearestEnemy() ?: return
        attemptPlace(session, target)
    }

    private fun nearestEnemy(): EntityTracker.TrackedEntity? {
        if (EntityTracker.selfRuntimeId <= 0L) return null
        val sx = EntityTracker.selfX; val sy = EntityTracker.selfY; val sz = EntityTracker.selfZ
        return EntityTracker.getPlayers(targetRange.value.toFloat())
            .asSequence()
            .filter { it.runtimeId != EntityTracker.selfRuntimeId }
            .filter { !friendSkip.value || !it.isFriendEntity }
            .minByOrNull { MathUtil.dist3sq(it.x, it.y, it.z, sx, sy, sz) }
    }

    private fun isFreeSpot(pos: Vector3i): Boolean {
        if (!WorldBlockTracker.hasData(pos.x, pos.y, pos.z)) return true
        val id = WorldBlockTracker.getBlockIdentifier(pos.x, pos.y, pos.z) ?: return true
        return id in NON_SOLID
    }

    private fun hasSolidBelow(pos: Vector3i): String? {
        val belowPos = Vector3i.from(pos.x, pos.y - 1, pos.z)
        if (!WorldBlockTracker.hasData(belowPos.x, belowPos.y, belowPos.z)) return null
        val below = WorldBlockTracker.getBlockIdentifier(belowPos.x, belowPos.y, belowPos.z)
        if (below == null || below in NON_SOLID) return null
        return below
    }

    private fun attemptPlace(session: NoxNoRelaySession, target: EntityTracker.TrackedEntity) {
        val tx = floor(target.x).toInt()
        val ty = floor(target.y).toInt()
        val tz = floor(target.z).toInt()

        val hasData = WorldBlockTracker.hasAnyTerrainData()

        var bedPos: Vector3i? = null
        var belowBlock: String? = null

        if (hasData) {
            val centerCandidate = Vector3i.from(tx, ty, tz)
            for ((dx, _, dz) in NEIGHBOR_OFFSETS) {
                val candidate = Vector3i.from(tx + dx, ty, tz + dz)
                if (!isFreeSpot(candidate)) continue

                val below = hasSolidBelow(candidate) ?: continue

                val secondHalfOk = NEIGHBOR_OFFSETS.any { (ndx, _, ndz) ->
                    val second = Vector3i.from(candidate.x + ndx, candidate.y, candidate.z + ndz)
                    isFreeSpot(second) && hasSolidBelow(second) != null
                }
                if (!secondHalfOk) continue

                bedPos = candidate
                belowBlock = below
                break
            }

            if (bedPos == null && isFreeSpot(centerCandidate)) {
                val below = hasSolidBelow(centerCandidate)
                if (below != null) {
                    bedPos = centerCandidate
                    belowBlock = below
                }
            }
        }

        // Never send a blind placement packet when terrain data says the
        // candidate is unknown/invalid. That was a common source of failed
        // BedAura placements and unnecessary server corrections.
        val finalBedPos = bedPos ?: return
        val finalBelowBlock = belowBlock ?: return

        val cx = finalBedPos.x + 0.5f
        val cy = finalBedPos.y + 0.5f
        val cz = finalBedPos.z + 0.5f
        
        if (MathUtil.dist3(cx, cy, cz, EntityTracker.selfX, EntityTracker.selfY + 1.62f, EntityTracker.selfZ) > placeRange.value) return

        lastAttemptMs = System.currentTimeMillis()

        if (!isFreeSpot(finalBedPos)) return
        if (hasSolidBelow(finalBedPos) == null) return

        val prepared = InventoryUtil.prepareItemForUse(session, bedIdentifier.value, noSwitch.value) ?: return
        val belowPos = Vector3i.from(finalBedPos.x, finalBedPos.y - 1, finalBedPos.z)
        val ok = InventoryUtil.sendPlacementUseRaw(session, prepared, belowPos, finalBelowBlock, blockFace = 1)
        InventoryUtil.revert(session, prepared)
        if (!ok) return

        active = Attempt(finalBedPos, System.currentTimeMillis())
    }
}