package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.InventoryUtil
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class HotbarSwitcherModule : BaseModule(
    name        = "HotbarSwitch",
    category    = ModuleCategory.COMBAT,
    description = "Silently cycles the hotbar between specific slots on the server side"
) {

    private val startSlot   = int("StartSlot",   0,   0, 8)
    private val endSlot     = int("EndSlot",     8,   0, 8)
    private val switchDelay = int("SwitchDelay", 100, 10, 1000)
    private val loopMode    = bool("Loop",       true)
    private val reverseMode = bool("Reverse",    false)
    private val shortcut    = bool("Shortcut",   false)

    @Volatile private var currentSlot = 0
    @Volatile private var direction = 1
    private var tickJob: Job? = null

    override fun onEnable() {
        super.onEnable()

        val lo = minOf(startSlot.value, endSlot.value)
        val hi = maxOf(startSlot.value, endSlot.value)

        direction = if (reverseMode.value) -1 else 1
        currentSlot = (if (direction > 0) lo else hi).coerceIn(0, 8)

        PacketEventBus.currentSession?.let { switchToSlot(it, currentSlot) }

        tickJob = scope.launch { tickLoop() }
    }

    override fun onDisable() {
        tickJob?.cancel()
        tickJob = null
        super.onDisable()
    }

    private suspend fun tickLoop() {
        while (currentCoroutineContext().isActive) {
            if (isEnabled) {

                val lo = minOf(startSlot.value, endSlot.value)
                val hi = maxOf(startSlot.value, endSlot.value)

                val session = PacketEventBus.currentSession
                if (session != null) {
                    advanceSlot(lo, hi)
                    switchToSlot(session, currentSlot)
                }
            }
            delay(switchDelay.value.toLong())
        }
    }

    private fun advanceSlot(lo: Int, hi: Int) {
        currentSlot += direction

        if (currentSlot > hi) {
            currentSlot = if (loopMode.value) lo else hi.also { direction = -1 }
        } else if (currentSlot < lo) {
            currentSlot = if (loopMode.value) hi else lo.also { direction = 1 }
        }
    }

    private fun switchToSlot(session: NoxNoRelaySession, slot: Int) {
        InventoryUtil.sendHotbarSelect(session, slot)

        EntityTracker.selfHotbarSlot = slot
    }
}
