package com.noxnoclient.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NoxNoBackground     = Color(0xFF0A0A0F)
val NoxNoSurface        = Color(0xFF15141C)
val NoxNoSurfaceVar     = Color(0xFF1E1D28)
val NoxNoSurfaceRaised  = Color(0xFF242331)

val NoxNoAccent         = Color(0xFFA855F7)
val NoxNoAccentLight    = Color(0xFFD8B4FE)
val NoxNoAccentDark     = Color(0xFF6D28D9)

val NoxNoOnBackground   = Color(0xFFF5F3FA)
val NoxNoOnSurface      = Color(0xFFE4E1ED)
val NoxNoOnSurfaceDim   = Color(0xFF8E8BA0)

val NoxNoOutline        = Color(0xFF2C2B38)
val NoxNoOutlineStrong  = Color(0xFF413F52)

val NoxNoError          = Color(0xFFFF5470)
val NoxNoSuccess        = Color(0xFF3DDC97)
val NoxNoWarning        = Color(0xFFFFB020)

val NoxNoConnectIdle    = Color(0xFF48465A)

val NoxNoSkinTone       = Color(0xFFF1D7B8)

val NoxNoModuleActive       = Color(0xFF3A1F63)
val NoxNoModuleActiveBorder = Color(0xFFA855F7)
val NoxNoModuleExpanded     = Color(0xFF4A2B7A)
val NoxNoModuleActiveText   = Color(0xFFF5F3FA)

val NoxNoPurple      = NoxNoAccent
val NoxNoPurpleLight = NoxNoAccentLight
val NoxNoPurpleDark  = NoxNoAccentDark

private val Scheme = darkColorScheme(
    primary          = NoxNoAccent,
    onPrimary        = Color.White,
    primaryContainer = NoxNoAccentDark,
    secondary        = NoxNoAccentLight,
    background       = NoxNoBackground,
    surface          = NoxNoSurface,
    surfaceVariant   = NoxNoSurfaceVar,
    onBackground     = NoxNoOnBackground,
    onSurface        = NoxNoOnSurface,
    outline          = NoxNoOutline,
    error            = NoxNoError
)

@Composable
fun NoxNoClientTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
