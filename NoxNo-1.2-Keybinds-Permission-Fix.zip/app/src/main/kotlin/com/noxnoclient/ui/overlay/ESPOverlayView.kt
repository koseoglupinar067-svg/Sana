package com.noxnoclient.ui.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.View
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.module.ModuleManager
import com.noxnoclient.module.visual.Performance
import com.noxnoclient.module.visual.FlatArrayModule
import com.noxnoclient.module.visual.TargetCircle
import com.noxnoclient.module.visual.TargetESP
import com.noxnoclient.module.visual.WatermarkModule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

class ESPOverlayView(context: Context) : View(context) {

    init {

        setBackgroundColor(Color.TRANSPARENT)
    }

    private val arrayListModule: FlatArrayModule? by lazy { ModuleManager.byName("FlatArray") as? FlatArrayModule }
    private val watermarkModule: WatermarkModule? by lazy { ModuleManager.byName("Watermark") as? WatermarkModule }

    private val targetEspModule: TargetESP? by lazy { ModuleManager.byName("TargetESP") as? TargetESP }
    private val targetCircleModule: TargetCircle? by lazy { ModuleManager.byName("TargetCircle") as? TargetCircle }
    private val performanceModule: Performance? by lazy { ModuleManager.byName("Performance") as? Performance }

    private var fpsWindowStartMs = System.currentTimeMillis()
    private var fpsFrameCount = 0

    private val renderScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var activeJob: Job? = null

    @Volatile private var hasActiveVisualModule = false
    @Volatile private var isLoopRunning = false

    private val idlePoller = Handler(Looper.getMainLooper())
    private val idleCheckRunnable = object : Runnable {
        override fun run() {
            if (!isLoopRunning && shouldRender()) {
                resumeLoop()
            }
            if (!isLoopRunning) {
                idlePoller.postDelayed(this, 400L)
            }
        }
    }

    private fun shouldRender(): Boolean {
        return hasActiveVisualModule || targetCircleModule?.isEnabled == true || performanceModule?.showPerformanceHud?.value == true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        activeJob?.cancel()
        activeJob = renderScope.launch {
            val arrayList = arrayListModule?.enabledFlow ?: flowOf(false)
            val targetEsp = targetEspModule?.enabledFlow ?: flowOf(false)
            val targetCircle = targetCircleModule?.enabledFlow ?: flowOf(false)
            val watermark = watermarkModule?.enabledFlow ?: flowOf(false)

            combine(arrayList, targetEsp, targetCircle, watermark) { a, b, c, d -> a || b || c || d }
                .collect { anyActive ->
                    hasActiveVisualModule = anyActive
                    if (anyActive && !isLoopRunning) resumeLoop()
                }
        }
        idlePoller.removeCallbacks(idleCheckRunnable)
        idlePoller.post(idleCheckRunnable)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        activeJob?.cancel()
        idlePoller.removeCallbacks(idleCheckRunnable)
        isLoopRunning = false
    }

    private fun resumeLoop() {
        if (isLoopRunning) return
        isLoopRunning = true
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val arrayList = arrayListModule
        if (arrayList != null && arrayList.isEnabled) {
            try { arrayList.render(canvas, width, height) } catch (_: Exception) {}
        }

        val targetEsp = targetEspModule
        if (targetEsp != null && targetEsp.isEnabled) {
            try { targetEsp.render(canvas, width, height) } catch (_: Exception) {}
        }

        val targetCircle = targetCircleModule
        if (targetCircle != null && targetCircle.isEnabled) {
            try { targetCircle.render(canvas, width, height) } catch (_: Exception) {}
        }

        val watermark = watermarkModule
        if (watermark != null && watermark.isEnabled) {
            try { watermark.render(canvas, width, height) } catch (_: Exception) {}
        }

        val hudOn = performanceModule?.showPerformanceHud?.value == true
        if (hudOn) {
            updateFpsWindow()
        }

        if (hasActiveVisualModule || targetCircleModule?.isEnabled == true || hudOn) {
            postInvalidateOnAnimation()
        } else {
            isLoopRunning = false
            idlePoller.removeCallbacks(idleCheckRunnable)
            idlePoller.post(idleCheckRunnable)
        }
    }

    private fun updateFpsWindow() {
        fpsFrameCount++
        val now = System.currentTimeMillis()
        val elapsed = now - fpsWindowStartMs
        if (elapsed >= 500L) {
            val fps = ((fpsFrameCount * 1000L) / elapsed).toInt()
            OverlayState.updatePerformanceStats(fps, EntityTracker.selfPingMs)
            fpsFrameCount = 0
            fpsWindowStartMs = now
        }
    }

    fun startRenderLoop() {
        resumeLoop()
    }
}
