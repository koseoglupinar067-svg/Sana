package com.noxnoclient.utils

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.Definitions
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEventBus
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.definitions.BlockDefinition
import org.cloudburstmc.protocol.bedrock.data.definitions.ItemDefinition
import org.cloudburstmc.protocol.bedrock.data.definitions.SimpleBlockDefinition
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerId
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerSlotType
import org.cloudburstmc.protocol.bedrock.data.inventory.FullContainerName
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.data.inventory.itemstack.request.ItemStackRequest
import org.cloudburstmc.protocol.bedrock.data.inventory.itemstack.request.ItemStackRequestSlotData
import org.cloudburstmc.protocol.bedrock.data.inventory.itemstack.request.action.ItemStackRequestAction
import org.cloudburstmc.protocol.bedrock.data.inventory.itemstack.request.action.DropAction
import org.cloudburstmc.protocol.bedrock.data.inventory.itemstack.request.action.PlaceAction
import org.cloudburstmc.protocol.bedrock.data.inventory.itemstack.request.action.SwapAction
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryActionData
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventorySource
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.ItemUseTransaction
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.ItemStackRequestPacket
import org.cloudburstmc.protocol.bedrock.packet.MobEquipmentPacket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

object InventoryUtil {

    const val OFFHAND_SLOT = 119
    const val HOTBAR_START = 0
    const val HOTBAR_END   = 8
    const val INV_START    = 9
    const val INV_END      = 35

    fun sendEquip(
        session    : NoxNoRelaySession,
        runtimeId  : Long,
        containerId: Int,
        slot       : Int,
        hotbarSlot : Int,
        item       : ItemData
    ) {
        val packet = MobEquipmentPacket().apply {
            this.runtimeEntityId = runtimeId
            this.containerId = containerId
            this.inventorySlot = slot
            this.hotbarSlot = hotbarSlot
            this.item = item
        }
        session.serverBound(packet)
    }

    fun sendOffhandEquip(session: NoxNoRelaySession, fromSlot: Int, itemData: ItemData) {
        sendEquip(
            session     = session,
            runtimeId   = EntityTracker.selfRuntimeId,
            containerId = ContainerId.OFFHAND,
            slot        = fromSlot,
            hotbarSlot  = 0,
            item        = itemData
        )
    }

    fun sendOffhandEquip(session: NoxNoRelaySession, fromSlot: Int, netId: Int, definition: ItemDefinition) {
        val item = ItemData.builder()
            .definition(definition)
            .netId(netId)
            .count(1)
            .damage(0)
            .usingNetId(true)
            .build()
        sendOffhandEquip(session, fromSlot, item)
    }

    fun sendHotbarSelect(session: NoxNoRelaySession, slot: Int) {
        val actualItem = EntityTracker.getInventoryItem(slot) ?: ItemData.AIR
        session.serverBound(MobEquipmentPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            containerId     = ContainerId.INVENTORY
            inventorySlot   = slot
            hotbarSlot      = slot
            item            = actualItem
        })
    }

    fun isEmpty(item: ItemData?): Boolean {
        if (item == null) return true
        return item.count <= 0
    }

    fun isTotem(item: ItemData?): Boolean {
        if (isEmpty(item)) return false

        val identifier = resolveIdentifier(item!!)

        if (identifier != null) {
            val result = identifier == "minecraft:totem_of_undying"
            return result
        }

        val runtimeId = runCatching { item.definition?.runtimeId }.getOrElse { null } ?: -1
        val totemRuntimeId = resolveTotemRuntimeIdFromCodec()
        val result = totemRuntimeId > 0 && runtimeId == totemRuntimeId
        return result
    }

    enum class ArmorSlotType(val slotIndex: Int) { HELMET(0), CHESTPLATE(1), LEGGINGS(2), BOOTS(3) }

    fun resolveArmorSlotType(item: ItemData?): ArmorSlotType? {
        if (isEmpty(item)) return null
        val identifier = resolveIdentifier(item!!) ?: return null
        return when {
            identifier.endsWith("_helmet") || identifier == "minecraft:turtle_helmet" -> ArmorSlotType.HELMET
            identifier.endsWith("_chestplate") || identifier == "minecraft:elytra" -> ArmorSlotType.CHESTPLATE
            identifier.endsWith("_leggings") -> ArmorSlotType.LEGGINGS
            identifier.endsWith("_boots") -> ArmorSlotType.BOOTS
            else -> null
        }
    }

    private val ARMOR_MATERIAL_TIER = mapOf(
        "leather" to 1, "golden" to 2, "chainmail" to 2,
        "iron" to 3, "diamond" to 4, "netherite" to 5
    )

    fun armorMaterialTier(item: ItemData?): Int {
        if (isEmpty(item)) return -1
        val identifier = resolveIdentifier(item!!) ?: return 0
        val material = identifier.removePrefix("minecraft:").substringBefore("_")
        return ARMOR_MATERIAL_TIER[material] ?: if (identifier == "minecraft:turtle_helmet") 2 else 0
    }

    private val stackRequestIdCounter = AtomicInteger(-1_000_000_000)
    fun nextStackRequestId(): Int = stackRequestIdCounter.decrementAndGet()

    fun sendInventoryMove(
        session: NoxNoRelaySession,
        sourceContainer: ContainerSlotType,
        sourceContainerId: Int,
        sourceSlot: Int,
        sourceItem: ItemData,
        destContainer: ContainerSlotType,
        destContainerId: Int,
        destSlot: Int,
        destItem: ItemData
    ) {
        if (!EntityTracker.inventoriesServerAuthoritative) {
            sendLegacyMove(session, sourceContainerId, sourceSlot, sourceItem, destContainerId, destSlot, destItem)
            return
        }
        sendItemStackMove(session, sourceContainer, sourceSlot, sourceItem, destContainer, destSlot, destItem)
    }

    private fun sendItemStackMove(
        session: NoxNoRelaySession,
        sourceContainer: ContainerSlotType,
        sourceSlot: Int,
        sourceItem: ItemData,
        destContainer: ContainerSlotType,
        destSlot: Int,
        destItem: ItemData
    ) {
        val srcSlotData = ItemStackRequestSlotData(
            sourceContainer, sourceSlot, sourceItem.netId, FullContainerName(sourceContainer, null)
        )
        val dstSlotData = ItemStackRequestSlotData(
            destContainer, destSlot, destItem.netId, FullContainerName(destContainer, null)
        )

        val action: ItemStackRequestAction = if (isEmpty(destItem)) {
            PlaceAction(sourceItem.count, srcSlotData, dstSlotData)
        } else {
            SwapAction(srcSlotData, dstSlotData)
        }

        val request = ItemStackRequest(nextStackRequestId(), arrayOf(action), arrayOf())
        session.serverBound(ItemStackRequestPacket().apply { requests.add(request) })
    }

    private fun sendLegacyMove(
        session: NoxNoRelaySession,
        sourceContainerId: Int,
        sourceSlot: Int,
        sourceItem: ItemData,
        destContainerId: Int,
        destSlot: Int,
        destItem: ItemData
    ) {
        val packet = InventoryTransactionPacket().apply {
            transactionType = InventoryTransactionType.NORMAL
            actions.add(InventoryActionData(InventorySource.fromContainerWindowId(sourceContainerId), sourceSlot, sourceItem, destItem))
            actions.add(InventoryActionData(InventorySource.fromContainerWindowId(destContainerId), destSlot, destItem, sourceItem))
        }
        session.serverBound(packet)
    }

    fun sendDropItem(session: NoxNoRelaySession, sourceSlot: Int, sourceItem: ItemData) {
        if (!EntityTracker.inventoriesServerAuthoritative) return

        val src = ItemStackRequestSlotData(
            ContainerSlotType.HOTBAR_AND_INVENTORY,
            sourceSlot,
            sourceItem.netId,
            FullContainerName(ContainerSlotType.HOTBAR_AND_INVENTORY, null)
        )
        val action: ItemStackRequestAction = DropAction(sourceItem.count, src, false)
        val request = ItemStackRequest(nextStackRequestId(), arrayOf(action), arrayOf())
        session.serverBound(ItemStackRequestPacket().apply { requests.add(request) })
    }

    fun sendSlotSwap(
        session: NoxNoRelaySession,
        sourceSlot: Int,
        sourceNetId: Int,
        destContainer: ContainerSlotType,
        destSlot: Int,
        destNetId: Int
    ) {
        val source = ItemStackRequestSlotData(
            ContainerSlotType.HOTBAR_AND_INVENTORY,
            sourceSlot,
            sourceNetId,
            FullContainerName(ContainerSlotType.HOTBAR_AND_INVENTORY, null)
        )
        val destination = ItemStackRequestSlotData(
            destContainer,
            destSlot,
            destNetId,
            FullContainerName(destContainer, null)
        )
        val request = ItemStackRequest(
            nextStackRequestId(),
            arrayOf<ItemStackRequestAction>(SwapAction(source, destination)),
            arrayOf<String>()
        )
        session.serverBound(ItemStackRequestPacket().apply { requests.add(request) })
    }

    fun resolveIdentifier(item: ItemData): String? {
        val fromDefinition = runCatching { item.definition?.identifier }.getOrElse { null }
        if (!fromDefinition.isNullOrBlank()) return fromDefinition

        val runtimeId = runCatching { item.definition?.runtimeId }.getOrElse { null } ?: return null
        if (runtimeId <= 0) return null

        val session = PacketEventBus.currentSession ?: return null
        val reg = runCatching { session.clientSession.peer.codecHelper.itemDefinitions }.getOrElse { null } ?: return null
        return runCatching { reg.getDefinition(runtimeId)?.identifier }.getOrElse { null }
    }

    private fun resolveTotemRuntimeIdFromCodec(): Int {
        val session = PacketEventBus.currentSession ?: return -1
        val reg = runCatching { session.clientSession.peer.codecHelper.itemDefinitions }.getOrElse { null } ?: return -1
        for (rid in 600..1800) {
            val def = runCatching { reg.getDefinition(rid) }.getOrElse { null } ?: continue
            if (def.identifier == "minecraft:totem_of_undying") return rid
        }
        return -1
    }

    @Deprecated("netId represents the stack, not the item type; use isTotem()", ReplaceWith("isTotem(item)"))
    fun isTotemNetId(netId: Int): Boolean = false

    private val FOOD_NET_IDS = setOf(
        260, 297, 319, 320, 349, 350, 354, 355,
        357, 360, 363, 364, 365, 366, 367, 420,
        423, 424, 469, 477
    )
    private val POTION_NET_IDS = setOf(373, 438, 441)
    private val WEAPON_NET_IDS = setOf(
        271, 272, 273, 274, 275, 276, 277, 278, 279, 280,
        293, 294, 295, 296, 297, 598, 599, 600, 601, 602
    )

    fun isFoodNetId(netId: Int)   : Boolean = netId in FOOD_NET_IDS
    fun isPotionNetId(netId: Int) : Boolean = netId in POTION_NET_IDS
    fun isWeaponNetId(netId: Int) : Boolean = netId in WEAPON_NET_IDS

    private const val BLOCK_DEF_SCAN_CAP   = 20000
    private const val BLOCK_DEF_MISS_LIMIT = 64

    data class PreparedItem(val slot: Int, val item: ItemData, val revertTo: Int?)

    private val blockDefCache = ConcurrentHashMap<String, BlockDefinition>()

    fun reset() {
        blockDefCache.clear()
    }

    private val FALLBACK_IDS = mapOf(
        "minecraft:obsidian"    to 49,
        "minecraft:cobblestone" to 4,
        "minecraft:bedrock"     to 7,
        "minecraft:end_crystal" to 198,
        "minecraft:piston"      to 33,
        "minecraft:sticky_piston" to 29,
        "minecraft:lever"       to 69,
        "minecraft:red_bed"     to 26,
        "minecraft:respawn_anchor" to 502,
        "minecraft:glowstone"   to 89
    )

    fun findItemInInventory(identifier: String): Pair<Int, ItemData>? {
        EntityTracker.getHeldItem()?.let { held ->
            if (held.count > 0 && resolveIdentifier(held) == identifier) {
                return EntityTracker.selfHotbarSlot to held
            }
        }
        for (slot in HOTBAR_START..HOTBAR_END) {
            val item = EntityTracker.getInventoryItem(slot) ?: continue
            if (item.count <= 0) continue
            if (resolveIdentifier(item) == identifier) return slot to item
        }
        return null
    }

    fun prepareItemForUse(
        session: NoxNoRelaySession,
        identifier: String,
        noSwitch: Boolean = true
    ): PreparedItem? {
        val (slot, item) = findItemInInventory(identifier) ?: run {
            return moveFromInventory(session, identifier, noSwitch)
        }

        if (slot == EntityTracker.selfHotbarSlot) return PreparedItem(slot, item, null)
        val original = EntityTracker.selfHotbarSlot
        sendHotbarSelect(session, slot)
        EntityTracker.selfHotbarSlot = slot
        return PreparedItem(slot, item, if (noSwitch) original else null)
    }

    private fun moveFromInventory(
        session: NoxNoRelaySession,
        identifier: String,
        noSwitch: Boolean
    ): PreparedItem? {
        for (slot in INV_START..INV_END) {
            val item = EntityTracker.getInventoryItem(slot) ?: continue
            if (item.count <= 0 || resolveIdentifier(item) != identifier) continue
            val destSlot = findEmptyHotbarSlot() ?: continue
            val destItem = EntityTracker.getInventoryItem(destSlot) ?: ItemData.AIR
            try {
                sendInventoryMove(
                    session = session,
                    sourceContainer = ContainerSlotType.HOTBAR_AND_INVENTORY,
                    sourceContainerId = ContainerId.INVENTORY,
                    sourceSlot = slot, sourceItem = item,
                    destContainer = ContainerSlotType.HOTBAR_AND_INVENTORY,
                    destContainerId = ContainerId.INVENTORY,
                    destSlot = destSlot, destItem = destItem
                )
            } catch (e: Exception) {
                continue
            }
            val original = EntityTracker.selfHotbarSlot
            sendHotbarSelect(session, destSlot)
            EntityTracker.selfHotbarSlot = destSlot
            return PreparedItem(destSlot, item, if (noSwitch) original else null)
        }
        return null
    }

    private fun findEmptyHotbarSlot(): Int? {
        for (slot in HOTBAR_START..HOTBAR_END) {
            val item = EntityTracker.getInventoryItem(slot)
            if (item == null || item.count <= 0) return slot
        }
        return null
    }

    fun revert(session: NoxNoRelaySession, prepared: PreparedItem) {
        prepared.revertTo?.let {
            sendHotbarSelect(session, it)
            EntityTracker.selfHotbarSlot = it
        }
    }

    fun sendPlacementUseRaw(
        session: NoxNoRelaySession,
        prepared: PreparedItem,
        blockPos: Vector3i,
        blockId: String,
        blockFace: Int = 1,
        clickPosition: Vector3f = Vector3f.from(0.5f, 1.0f, 0.5f)
    ): Boolean {
        val blockDef = getBlockDefinition(session, blockId) ?: run {
            return false
        }
        val playerPos = Vector3f.from(EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ)
        val freshItem = EntityTracker.getInventoryItem(prepared.slot) ?: prepared.item

        val toItem = if (freshItem.count > 1)
            freshItem.toBuilder().count(freshItem.count - 1).build()
        else ItemData.AIR

        return try {
            session.serverBound(InventoryTransactionPacket().apply {
                transactionType          = InventoryTransactionType.ITEM_USE
                actionType               = 0
                this.blockPosition       = blockPos
                this.blockFace           = blockFace
                hotbarSlot               = prepared.slot
                itemInHand               = freshItem
                playerPosition           = playerPos
                this.clickPosition       = clickPosition
                blockDefinition          = blockDef
                triggerType              = ItemUseTransaction.TriggerType.PLAYER_INPUT
                clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
                actions.add(InventoryActionData(InventorySource.fromContainerWindowId(ContainerId.INVENTORY), prepared.slot, freshItem, toItem))
            })
            true
        } catch (e: Exception) {
            false
        }
    }

    fun sendInteract(
        session: NoxNoRelaySession,
        blockPos: Vector3i,
        blockId: String,
        blockFace: Int = 1,
        clickPosition: Vector3f = Vector3f.from(0.5f, 0.5f, 0.5f)
    ): Boolean {
        val blockDef  = getBlockDefinition(session, blockId) ?: return false
        val playerPos = Vector3f.from(EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ)
        val heldItem = EntityTracker.getInventoryItem(EntityTracker.selfHotbarSlot) ?: ItemData.AIR
        return try {
            session.serverBound(InventoryTransactionPacket().apply {
                transactionType          = InventoryTransactionType.ITEM_USE
                actionType               = 0
                this.blockPosition       = blockPos
                this.blockFace           = blockFace
                hotbarSlot               = EntityTracker.selfHotbarSlot
                itemInHand               = ItemData.AIR
                playerPosition           = playerPos
                this.clickPosition       = clickPosition
                blockDefinition          = blockDef
                triggerType              = ItemUseTransaction.TriggerType.PLAYER_INPUT
                clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
                actions.add(InventoryActionData(InventorySource.fromContainerWindowId(ContainerId.INVENTORY), EntityTracker.selfHotbarSlot, heldItem, heldItem))
            })
            true
        } catch (_: Exception) { false }
    }

    fun getBlockDefinition(
        session: NoxNoRelaySession,
        targetId: String
    ): BlockDefinition? {
        val namesToTry = if (targetId.startsWith("minecraft:")) {
            listOf(targetId, targetId.removePrefix("minecraft:"))
        } else {
            listOf("minecraft:$targetId", targetId)
        }

        for (name in namesToTry) {
            blockDefCache[name]?.let {
                return it
            }
        }

        val blockDefs = session.clientSession.peer.codecHelper.blockDefinitions

        if (blockDefs is Definitions.NbtBlockDefinitionRegistry) {
            for (name in namesToTry) {
                blockDefs.findByName(name)?.let {
                    blockDefCache[targetId] = it
                    blockDefCache[name] = it
                    return it
                }
            }
        } else {
            try {
                if (blockDefs != null) {
                    var i = 0; var misses = 0
                    while (i < BLOCK_DEF_SCAN_CAP && misses < BLOCK_DEF_MISS_LIMIT) {
                        val def = try { blockDefs.getDefinition(i) } catch (_: Exception) { null }
                        if (def == null) { misses++; i++; continue }
                        misses = 0
                        val id = when (def) {
                            is SimpleBlockDefinition -> def.identifier
                            is Definitions.NbtBlockDefinitionRegistry.NbtBlockDefinition -> def.tag.getString("name")
                            else -> null
                        }
                        if (id in namesToTry) {
                            blockDefCache[targetId] = def
                            return def
                        }
                        i++
                    }
                }
            } catch (e: Exception) {
            }
        }

        val fallbackKey = namesToTry.firstOrNull { FALLBACK_IDS.containsKey(it) } ?: targetId
        val fallbackId = FALLBACK_IDS[fallbackKey] ?: FALLBACK_IDS[targetId] ?: run {
            return null
        }
        val fallback = SimpleBlockDefinition(
            targetId, fallbackId,
            org.cloudburstmc.nbt.NbtMap.builder()
                .putString("name", targetId)
                .putCompound("states", org.cloudburstmc.nbt.NbtMap.builder().build())
                .build()
        )
        blockDefCache[targetId] = fallback
        return fallback
    }

    fun posKey(x: Int, y: Int, z: Int): Long =
        ((x.toLong() and 0x3FFFFFFL) shl 38) or
        ((y.toLong() and 0xFFFL)     shl 26) or
        (z.toLong() and 0x3FFFFFFL)

    private val NON_SOLID = setOf(
        "minecraft:air", "minecraft:water", "minecraft:flowing_water",
        "minecraft:lava", "minecraft:flowing_lava",
        "minecraft:void_air", "minecraft:cave_air"
    )

    private val NEIGHBOR_FACES = listOf(
        Triple(0, -1, 0) to 1,
        Triple(0, 1, 0)  to 0,
        Triple(0, 0, -1) to 3,
        Triple(0, 0, 1)  to 2,
        Triple(1, 0, 0)  to 4,
        Triple(-1, 0, 0) to 5
    )

    fun findClickableNeighbor(x: Int, y: Int, z: Int): Triple<Vector3i, String, Int>? {
        var anyDataFound = false
        for ((offset, face) in NEIGHBOR_FACES) {
            val nx = x + offset.first; val ny = y + offset.second; val nz = z + offset.third
            val id = WorldBlockTracker.getBlockIdentifier(nx, ny, nz)
            if (id == null) continue
            anyDataFound = true
            if (id in NON_SOLID) continue
            return Triple(Vector3i.from(nx, ny, nz), id, face)
        }

        if (!anyDataFound) {
            return Triple(Vector3i.from(x, y - 1, z), "minecraft:obsidian", 1)
        }
        return null
    }
}
