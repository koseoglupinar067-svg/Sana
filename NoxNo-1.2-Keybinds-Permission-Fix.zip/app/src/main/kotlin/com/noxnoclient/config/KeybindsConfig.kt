package com.noxnoclient.config

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.noxnoclient.module.ModuleManager
import com.noxnoclient.module.keybinds.KeybindsManager

class KeybindsConfig(context: Context) {
    private val prefs = context.getSharedPreferences("noxno_keybinds_config", Context.MODE_PRIVATE)
    private val gson = Gson()

    data class SavedKeybind(
        val id: String,
        val moduleName: String,
        val keyCode: Int,
        val requiresCtrl: Boolean,
        val requiresShift: Boolean,
        val requiresAlt: Boolean,
        val isActive: Boolean
    )

    fun save() {
        val data = KeybindsManager.getAllKeybinds().values.map {
            SavedKeybind(it.id, it.module.name, it.keyCode, it.requiresCtrl, it.requiresShift, it.requiresAlt, it.isActive)
        }
        prefs.edit().putString("keybinds_data", gson.toJson(data)).apply()
    }

    fun load() {
        val json = prefs.getString("keybinds_data", null) ?: return
        try {
            val type = object : TypeToken<List<SavedKeybind>>() {}.type
            val data: List<SavedKeybind> = gson.fromJson(json, type)
            data.forEach { saved ->
                val module = ModuleManager.byName(saved.moduleName) ?: return@forEach
                val existing = KeybindsManager.getKeybind(saved.id)
                if (existing == null) {
                    KeybindsManager.registerKeybind(
                        saved.id, module, saved.keyCode,
                        saved.requiresCtrl, saved.requiresShift, saved.requiresAlt
                    )
                    KeybindsManager.setKeybindActive(saved.id, saved.isActive)
                } else {
                    KeybindsManager.updateKeybind(
                        saved.id, saved.keyCode,
                        saved.requiresCtrl, saved.requiresShift, saved.requiresAlt, saved.isActive
                    )
                }
            }
        } catch (_: Exception) { }
    }
}
