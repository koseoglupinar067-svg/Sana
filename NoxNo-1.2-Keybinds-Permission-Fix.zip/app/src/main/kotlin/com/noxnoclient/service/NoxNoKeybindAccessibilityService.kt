package com.noxnoclient.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.os.Build
import android.view.KeyEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.noxnoclient.R
import com.noxnoclient.module.ModuleManager
import com.noxnoclient.module.keybinds.KeybindsManager

/**
 * Receives hardware keyboard events while Minecraft is the foreground app.
 * Returning false for text input lets the key continue to Minecraft, so chat
 * typing is never swallowed by a keybind.
 */
class NoxNoKeybindAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount != 0) return false

        val controller = ModuleManager.byName("Keybinds")
        if (controller?.isEnabled != true) return false
        if (controller.getSettingValue<Boolean>("Global Keybinds") == false) return false

        val packageName = activePackageName() ?: return false
        if (!isMinecraftPackage(packageName)) return false

        val ignoreText = controller.getSettingValue<Boolean>("Ignore Text Input") != false
        if (ignoreText && isTextInputFocused()) return false

        // Returning true consumes only a matched keybind. All other keys pass through.
        return KeybindsManager.handle(event)
    }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    private fun activePackageName(): String? = try {
        rootInActiveWindow?.packageName?.toString()
            ?: windows.firstOrNull { it.isActive }?.root?.packageName?.toString()
    } catch (_: Exception) {
        null
    }

    private fun isMinecraftPackage(pkg: String): Boolean = pkg in setOf(
        "com.mojang.minecraftpe",
        "com.netease.mc",
        "com.mojang.minecrafttrialpe"
    )

    private fun isTextInputFocused(): Boolean {
        return try {
            val root = rootInActiveWindow ?: return false
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null) {
                val editable = focused.isEditable
                val className = focused.className?.toString().orEmpty()
                focused.recycle()
                editable || className.contains("EditText", ignoreCase = true) ||
                    className.contains("TextField", ignoreCase = true)
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        fun isEnabled(context: Context): Boolean = try {
            val manager = context.getSystemService(Context.ACCESSIBILITY_SERVICE)
                as android.view.accessibility.AccessibilityManager
            manager.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK
            ).any { info -> info.resolveInfo?.serviceInfo?.packageName == context.packageName }
        } catch (_: Exception) {
            false
        }
    }
}
