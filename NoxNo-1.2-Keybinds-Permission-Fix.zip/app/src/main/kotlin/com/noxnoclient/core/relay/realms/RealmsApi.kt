package com.noxnoclient.core.relay.realms

import com.noxnoclient.auth.MicrosoftAuthManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

data class RealmInfo(
    val id: Long,
    val name: String,
    val ownerXuid: String,
    val state: String,
    val expired: Boolean,
    val maxPlayers: Int
)

data class RealmAddress(
    val host: String,
    val port: Int,
    val networkProtocol: String
)

object RealmsApi {

    private const val BASE           = "https://pocket.realms.minecraft.net"
    private const val CLIENT_VERSION = "1.21.60"
    private const val USER_AGENT     = "MCPE/UWP"

    class RealmsException(message: String, val httpCode: Int = -1) : Exception(message)

    suspend fun listRealms(): List<RealmInfo> = withContext(Dispatchers.IO) {
        val body = request("GET", "/worlds")
        val arr  = JSONObject(body).optJSONArray("servers") ?: JSONArray()

        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            RealmInfo(
                id         = o.optLong("id"),
                name       = o.optString("name"),
                ownerXuid  = o.optString("ownerUUID"),
                state      = o.optString("state"),
                expired    = o.optBoolean("expired"),
                maxPlayers = o.optInt("maxPlayers")
            )
        }
    }

    suspend fun joinRealm(realmId: Long): RealmAddress = withContext(Dispatchers.IO) {
        val json     = JSONObject(request("GET", "/worlds/$realmId/join"))
        val protocol = json.optString("networkProtocol", "DEFAULT")

        if (protocol != "DEFAULT") {
            throw RealmsException("This realm uses NetherNet (WebRTC), which is not supported by the RakNet relay")
        }

        val address = json.optString("address")
        val parts   = address.split(":")
        if (parts.size != 2) throw RealmsException("Unexpected address format: $address")

        RealmAddress(
            host            = parts[0],
            port            = parts[1].toIntOrNull() ?: 19132,
            networkProtocol = protocol
        )
    }

    private suspend fun request(method: String, path: String): String {
        val xbl = MicrosoftAuthManager.getRealmsXblToken()
            ?: throw RealmsException("No Xbox Live session - you must sign in with a Microsoft account first")

        val conn = (URL("$BASE$path").openConnection() as HttpURLConnection).apply {
            requestMethod   = method
            connectTimeout  = 10_000
            readTimeout     = 10_000
            setRequestProperty("Authorization", "XBL3.0 $xbl")
            setRequestProperty("Client-Version", CLIENT_VERSION)
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "*/*")
        }

        try {
            val code   = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text   = stream?.let { BufferedReader(InputStreamReader(it)).readText() } ?: ""

            if (code !in 200..299) {
                throw RealmsException("Realms API $path -> HTTP $code: $text", code)
            }
            return text
        } finally {
            conn.disconnect()
        }
    }
}
