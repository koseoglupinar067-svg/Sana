USERNAME="NoxDec"
REPO="github.com/NoxRo/NoxNo.git"
BRANCH="main"

if [ -z "$NOX_GITHUB_TOKEN" ]; then
    echo "Hata: NOX_GITHUB_TOKEN tanımlı değil!"
    echo "Lütfen: export NOX_GITHUB_TOKEN=senin_tokenin"
    exit 1
fi

git add .
git commit -m "Force push via env variable: $(date +'%Y-%m-%d %H:%M:%S')"

echo "ZORLA push yapılıyor..."
git push -f "https://$USERNAME:$NOX_GITHUB_TOKEN@$REPO" "$BRANCH"

echo "İşlem Tamam!"